
CREATE TABLE `userinfo` (
  `USER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '사용자ID',
  `PASSWORD` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '비밀번호',
  `USER_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '사용자명',
  `USER_SE` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용자구분',
  `USER_TELNO` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '전화번호',
  `USER_EMAIL` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '이메일',
  `CL_CODE` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '작업구분',
  `CL_CODE_ID` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '작업상세구분',
  `LOCK_CNT` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '실패횟수',
  `USER_DEL_DT` datetime DEFAULT NULL COMMENT '삭제일자',
  `LAST_LOG_DT` datetime DEFAULT NULL COMMENT '최근접속일자',
  `SBSCRB_DE` datetime DEFAULT NULL COMMENT '가입일',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`USER_ID`),
  KEY `userinfo_IDX` (`USER_NM`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='사용자관리';

CREATE TABLE `comtccmmncode` (
  `CODE_ID` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '코드ID',
  `CODE_ID_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '코드ID명',
  `CODE_ID_DC` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '코드ID설명',
  `USE_AT` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용여부',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일자',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일자',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`CODE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='공통코드';

CREATE TABLE `comtccmmndetailcode` (
  `CODE_ID` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '코드ID',
  `CODE` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '상세코드',
  `CODE_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '상세코드명',
  `CODE_DC` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '상세코드설명',
  `USE_AT` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용여부',
  `CODE_NO` varchar(3) DEFAULT NULL COMMENT '순번',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일자',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일자',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`CODE_ID`,`CODE`),
  CONSTRAINT `comtccmmndetailcode_FK` FOREIGN KEY (`CODE_ID`) REFERENCES `comtccmmncode` (`CODE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='공통상세코드';

CREATE TABLE `comtccmmnclcode` (
  `CL_CODE` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '분류코드',
  `CL_CODE_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '분류코드명',
  `CL_CODE_DC` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '분류코드설명',
  `USE_AT` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용여부',
  `CL_CODE_NO` varchar(100) DEFAULT NULL COMMENT '순번',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일자',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일자',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`CL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='분류코드';

CREATE TABLE `comtccmmndetailclcode` (
  `CL_CODE` char(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '분류코드',
  `CL_CODE_ID` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '분류상세코드',
  `CL_CODE_ID_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '분류상세명',
  `CL_CODE_ID_DC` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '분류상세내용',
  `USE_AT` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용여부',
  `CL_CODE_ID_NO` varchar(3) DEFAULT NULL COMMENT '순번',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`CL_CODE`,`CL_CODE_ID`),
  CONSTRAINT `comtccmmndetailclcode_FK` FOREIGN KEY (`CL_CODE`) REFERENCES `comtccmmnclcode` (`CL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='분류상세코드';

CREATE TABLE `userloginlog` (
  `LOG_ID` int NOT NULL AUTO_INCREMENT COMMENT '로그ID',
  `USER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용자ID',
  `USER_IP` varchar(23) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '사용자IP',
  `USER_MTHD` char(4) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '접속구분(로그인:I, 로그아웃:O)',
  `CREAT_DT` datetime DEFAULT NULL COMMENT '생성일시',
  PRIMARY KEY (`LOG_ID`),
  KEY `userloginlog_IDX` (`USER_ID`,`CREAT_DT`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='접속로그';

CREATE TABLE `schedulemanage` (
  `SCHDUL_ID` int NOT NULL AUTO_INCREMENT COMMENT '일정ID',
  `SCHDUL_SJ` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '제목',
  `SCHDUL_CN` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '내용',
  `SCHDUL_BGNDT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '시작일시',
  `SCHDUL_ENDDT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '종료일시',
  `ALLDAY` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '종일여부',
  `SCHDUL_CLR` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '일정색상',
  `CL_CODE` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '분류코드',
  `CL_CODE_ID` varchar(6) DEFAULT NULL COMMENT '분류코드상세',
  `SEND_SE` varchar(3) DEFAULT NULL COMMENT '알림구분',
  `SENDDT` varchar(50) DEFAULT NULL COMMENT '알림일시',
  `SCHDUL_ADMIN_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '관리자',
  `SCHDUL_ADMIN_TELNO` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '관리자전화번호',
  `SCHDUL_CHARGER_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '담당자',
  `SCHDUL_CHARGER_TELNO` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '담당자전화번호',
  `SCHDUL_FREQ` varchar(20) DEFAULT NULL COMMENT '일정주기',
  `SCHDUL_INTERVAL` varchar(10) DEFAULT NULL COMMENT '일정간격',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`SCHDUL_ID`),
  KEY `schedulemanage_IDX` (`SCHDUL_BGNDT`) USING BTREE,
  KEY `schedulemanage_IDX1` (`SCHDUL_ENDDT`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE `schedulemanagehist` (
  `SCHDUL_ID` int NOT NULL COMMENT '일정ID',
  `CHANGE_DT` datetime NOT NULL COMMENT '변경일자',
  `SCHDUL_SJ` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '제목',
  `SCHDUL_CN` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '내용',
  `SCHDUL_BGNDT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '시작일시',
  `SCHDUL_ENDDT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '종료일시',
  `ALLDAY` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '종일여부',
  `SCHDUL_CLR` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '일정색상',
  `CL_CODE` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '작업구분',
  `CL_CODE_ID` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '작업상세구분',
  `SEND_SE` varchar(3) DEFAULT NULL COMMENT '알림구분',
  `SENDDT` varchar(50) DEFAULT NULL COMMENT '알림일시',
  `SCHDUL_ADMIN_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '관리자',
  `SCHDUL_ADMIN_TELNO` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '관리자전화번호',
  `SCHDUL_CHARGER_NM` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '담당자',
  `SCHDUL_CHARGER_TELNO` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '담당자전화번호',
  `SCHDUL_FREQ` varchar(20) DEFAULT NULL COMMENT '일정주기',
  `SCHDUL_INTERVAL` varchar(10) DEFAULT NULL COMMENT '일정간격',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`SCHDUL_ID`,`CHANGE_DT`),
  KEY `schedulemanagehist_IDX` (`CHANGE_DT`,`CL_CODE`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='일정관리변경이력';

CREATE TABLE `smsinfo` (
  `SMS_ID` int NOT NULL AUTO_INCREMENT COMMENT 'SMS ID',
  `USERCODE` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '유저코드(kangwonland6)',
  `REQNAME` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '발신자',
  `REQPHONE` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '발신연락처',
  `CALLNAME` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '수신자',
  `CALLPHONE` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '수신연락처',
  `SUBJECT` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '제목',
  `MSG` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '메시지',
  `REQTIME` datetime DEFAULT NULL COMMENT '전송일시',
  `RESULT` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '전송방식',
  `KIND` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '발송구분(MMS:M,SMS:S)',
  `SEND_PROG_MOD` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '발송모드',
  `RECV_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '수신자ID',
  `FKCONTENT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '임시키값',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일자',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  PRIMARY KEY (`SMS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='SMS 발송';


CREATE TABLE `schedulesmsinfo` (
  `SCHDUL_ID` int NOT NULL COMMENT '일정ID',
  `SMS_ID` int NOT NULL COMMENT 'SMSID',
  `SENDDT` varchar(50) DEFAULT NULL COMMENT '알림일시',
  `SEND_TRPR` varchar(50) DEFAULT NULL COMMENT '발송대상자',
  `SCHDUL_FREQ_SN` int DEFAULT NULL COMMENT '일정주기 일련번호',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  PRIMARY KEY (`SCHDUL_ID`,`SMS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='일정관리 SMS ID정보';


CREATE TABLE `schedulefreqinfo` (
  `SCHDUL_ID` int NOT NULL COMMENT '일정ID',
  `SCHDUL_FREQ_SN` int NOT NULL COMMENT '주기일련번호',
  `SCHDUL_FREQ_BGNDT` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '시작일시',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`SCHDUL_ID`,`SCHDUL_FREQ_SN`),
  KEY `schedulefreqinfo_IDX` (`SCHDUL_ID`,`SCHDUL_FREQ_SN`) USING BTREE,
  KEY `schedulefreqinfo_IDX1` (`SCHDUL_ID`,`SCHDUL_FREQ_BGNDT`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='일정관리 주기정보';

CREATE TABLE `holidayinfo` (
  `HOLIDAY_ID` int NOT NULL AUTO_INCREMENT COMMENT '공휴일ID',
  `HOLIDAY_DT` date NOT NULL COMMENT '공휴일자',
  `HOLIDAY_NM` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '공휴일명',
  `HOLIDAY_YN` varchar(1) DEFAULT NULL COMMENT '공휴일여부',
  `FRST_REGIST_DT` datetime DEFAULT NULL COMMENT '최초등록일시',
  `FRST_REGISTER_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최초등록자ID',
  `LAST_UPDT_DT` datetime DEFAULT NULL COMMENT '최종수정일시',
  `LAST_UPDUSR_ID` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '최종수정자ID',
  PRIMARY KEY (`HOLIDAY_ID`),
  KEY `holidayinfo_IDX` (`HOLIDAY_DT`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='공휴일정보';