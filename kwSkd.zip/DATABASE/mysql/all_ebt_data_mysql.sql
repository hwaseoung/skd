INSERT INTO comtccmmnclcode (CL_CODE,CL_CODE_NM,CL_CODE_DC,USE_AT,CL_CODE_NO,FRST_REGIST_DT,FRST_REGISTER_ID,LAST_UPDT_DT,LAST_UPDUSR_ID) VALUES
('ALL', '전체', '전체 관리자만 사용 가능', 'Y', '0', sysdate(),'admin',sysdate(),'admin'),
('PJC','사업관리','사업관리 관리 코드','Y','2',sysdate(),'admin',sysdate(),'admin'),
('PRJ','프로젝트','프로젝트 관리 코드','Y','1',sysdate(),'admin',sysdate(),'admin');

INSERT INTO comtccmmndetailclcode
(CL_CODE, CL_CODE_ID, CL_CODE_ID_NM, CL_CODE_ID_DC, USE_AT,CL_CODE_ID_NO, FRST_REGIST_DT, FRST_REGISTER_ID, LAST_UPDT_DT, LAST_UPDUSR_ID) VALUES
('PJC', 'PJC001', '라이선스', '라이선스 갱신', 'Y', '1',sysdate(),'admin',sysdate(),'admin'),
('PJC', 'PJC002', '장비', '장비교체 및 점검', 'Y', '2',sysdate(),'admin',sysdate(),'admin'),
('PRJ', 'PRJ001', '신규', '신규 프로젝트', 'Y', '1',sysdate(),'admin',sysdate(),'admin'),
('PRJ', 'PRJ002', '고도화', '고도화 프로젝트', 'Y','2', sysdate(),'admin',sysdate(),'admin');


INSERT INTO comtccmmncode
(CODE_ID, CODE_ID_NM, CODE_ID_DC, USE_AT, FRST_REGIST_DT, FRST_REGISTER_ID, LAST_UPDT_DT, LAST_UPDUSR_ID) VALUES
('CM0001', '사용자유형', 'ADMIN, USER', 'Y', sysdate(),'admin',sysdate(),'admin'),
('CM0002', '알림기준', '하루전, 일주일전, 한달, 기타', 'Y', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '일정색상', '파란색, 빨간색, 주황색, 연두색, 초록색', 'Y', sysdate(),'admin',sysdate(),'admin'),
('CM0004', '일정주기', '년, 월, 주, 일 구분 코드', 'Y', sysdate(),'admin',sysdate(),'admin');

INSERT INTO comtccmmndetailcode
(CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT,CODE_NO, FRST_REGIST_DT, FRST_REGISTER_ID, LAST_UPDT_DT, LAST_UPDUSR_ID) VALUES
('CM0001', 'ADMIN', '관리자', '관리자 권한', 'Y', '2',sysdate(),'admin',sysdate(),'admin'),
('CM0001', 'USER', '사용자', '사용자 권한', 'Y', '1',sysdate(),'admin',sysdate(),'admin'),
('CM0002', 'day', '하루전', '일정 시작 하루전 알림(시간 08:30)', 'Y', '1',sysdate(),'admin',sysdate(),'admin'),
('CM0002', 'mon', '한달전', '일정 시작 한달전 알림(시간 08:30)', 'Y', '3',sysdate(),'admin',sysdate(),'admin'),
('CM0002', 'ETC', '기타', '기타 선택 시 알림 일정 선택 가능', 'Y', '99',sysdate(),'admin',sysdate(),'admin'),
('CM0002', 'wek', '일주일전', '일정 시작 일주일전 알림(시간 08:30)', 'Y', '2',sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#74c0fc', '파란색', '일정 구분 색상', 'Y', '1', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#D25565', '빨간색', '일정 구분 색상', 'Y', '2', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#ffa94d', '주황색', '일정 구분 색상', 'Y', '3', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#63e6be', '연두색', '일정 구분 색상', 'Y', '4', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#a9e34b', '초록색', '일정 구분 색상', 'Y', '5', sysdate(),'admin',sysdate(),'admin'),
('CM0003', '#f06595', '핑크색', '일정 구분 색상', 'Y', '6', sysdate(),'admin',sysdate(),'admin'),
('CM0004', 'daily', '일', '일 주기', 'Y', '4', sysdate(),'admin',sysdate(),'admin'),
('CM0004', 'monthly', '월', '월 주기', 'Y', '2',sysdate(),'admin',sysdate(),'admin'),
('CM0004', 'weekly', '주', '주 주기', 'Y', '1', sysdate(),'admin',sysdate(),'admin'),
('CM0004', 'yearly', '년', '년 주기', 'Y', '3', sysdate(),'admin',sysdate(),'admin');


INSERT INTO userinfo
(USER_ID, PASSWORD, USER_NM, USER_SE, USER_TELNO, USER_EMAIL, CL_CODE, CL_CODE_ID, LOCK_CNT, USER_DEL_DT, LAST_LOG_DT, SBSCRB_DE, FRST_REGIST_DT, FRST_REGISTER_ID, LAST_UPDT_DT, LAST_UPDUSR_ID) VALUES
('admin', 'JfQ7FIatlaE5jj7rPYO8QBABX8yb7bNbQy4AKY1QIfc=', '관리자', 'ADMIN', '', '', '', '', '0', NULL, NULL, sysdate(), sysdate(),'admin',sysdate(),'admin'),
('user', 'CgQblGLKpKMbrDVn4Lbm/ZEAeH2yq0M9lvbReMq/zpA=', '사용자', 'USER', '123123', '', 'PJC', '', '0', NULL, NULL, sysdate(), sysdate(),'admin',sysdate(),'admin'),
('user1', 'gRFeMeIqWAGxl3UOwS16Ua1pOqAX7Mi8oDPL1QCpKLY=', '사용자1', 'USER', '', '', 'PJC', 'PJC002', '0', NULL, NULL, sysdate(), sysdate(),'admin',sysdate(),'admin');

