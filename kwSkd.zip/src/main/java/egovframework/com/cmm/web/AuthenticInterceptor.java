package egovframework.com.cmm.web;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.egovframe.rte.fdl.cmmn.exception.EgovBizException;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import egovframework.com.cmm.EgovMessageSource;

public class AuthenticInterceptor extends HandlerInterceptorAdapter {
	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;
	
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException {
        //System.out.println("preHandle >>>  Controller 실행 전 실행");
    	//세션에 계정정보(LoginVO)가 있는지 여부로 인증 여부를 체크한다. 계정정보(LoginVO)가 없다면, 로그인 페이지로 이동한다.
        try {
        	
        	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
        	if(!isAuthenticated) {
        		 ModelAndView modelAndView = new ModelAndView("forward:/uat/uia/kwLoginUsr.do");
                 modelAndView.addObject("message", egovMessageSource.getMessage("fail.common.login"));
                 throw new ModelAndViewDefiningException(modelAndView);
        	}else {
        		return true;
        	}
        } catch (Exception e) {
            ModelAndView modelAndView = new ModelAndView("forward:/uat/uia/kwLoginUsr.do");
            modelAndView.addObject("message", egovMessageSource.getMessage("fail.common.login"));
            throw new ModelAndViewDefiningException(modelAndView);
        }
    }
 
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modeAndView) throws ServletException {
        //System.out.println("postHandle >>>  Controller 실행 후 실행");
    }
 
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex){
        //System.out.println("afterCompletion >>>  preHandle 메소드 return값이 true일 때 실행");
    }

}
