package egovframework.com.cmm.web;

import egovframework.com.cmm.EgovWebUtil;
import org.egovframe.rte.fdl.property.EgovPropertyService;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EgovComUtlController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovComUtlController.class);
	
	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	@Resource(name = "egovPageLinkWhitelist")
    protected List<String> egovWhitelist;
	
	/**
	 * JSP 호출작업만 처리하는 공통 함수
	 */
	@RequestMapping(value = "/EgovPageLink.do")
	public String moveToPage(@RequestParam(value="linkIndex",required=true,defaultValue="0") Integer linkIndex,
			HttpSession session, @RequestParam(value = "baseMenuNo", required = false) String baseMenuNo) {
		
		String link = "";
		
		// 화이트 리스트가 비었는지 확인
		if (egovWhitelist == null || egovWhitelist.isEmpty() || egovWhitelist.size() <= linkIndex) {
			
			LOGGER.debug("Page Link WhiteList Error! Please check whitelist!");
			
			link="cmm/error/egovError";
			
			return link;
		}
		
		link = egovWhitelist.get(linkIndex);
		
		link = link.replace(";", "");
		link = link.replace("%", "");
		link = link.replace(".", "");
		
		if(link.indexOf(",")>-1){
		    link=link.substring(0,link.indexOf(","));
		}
		
		// 선택된 메뉴정보를 세션으로 등록한다.
		if (baseMenuNo != null && !baseMenuNo.equals("")) {
			session.setAttribute("menuNo", baseMenuNo);
			session.setAttribute("baseMenuNo", baseMenuNo);
		}
		
		// 안전한 경로 문자열로 조치
		link = EgovWebUtil.filePathBlackList(link);
		
		return link;
	}

	/**
	 * validation rule dynamic java script
	 */
	@RequestMapping("/validator.do")
	public String validate() {
		return "cmm/validator";
	}

}