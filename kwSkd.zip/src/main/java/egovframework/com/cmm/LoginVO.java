package egovframework.com.cmm;

import java.io.Serializable;

public class LoginVO implements Serializable{
	
	private static final long serialVersionUID = -8274004534207618049L;
	
	/** 아이디 */
	private String id;
	/** 이름 */
	private String name;
	/** 전화번호 */
	private String telNo;
	/** 이메일주소 */
	private String email;
	/** 비밀번호 */
	private String password;
	/** 사용자구분 */
	private String userSe;
	/** 분류코드 */
	private String clCode;
	/** 분류명 */
	private String clCodeNm;
	/** 분류상세코드 */
	private String clCodeId;
	/** 분류상세명 */
	private String clCodeIdNm;
	/** 사용자 IP정보 */
	private String ip;
	/** 잠금횟수 */
	private String lockCnt;
	/** 삭제일 */
	private String userDelDt;
	/** 최근접속일 */
	private String lastLogDt;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelNo() {
		return telNo;
	}
	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserSe() {
		return userSe;
	}
	public void setUserSe(String userSe) {
		this.userSe = userSe;
	}
	public String getClCode() {
		return clCode;
	}
	public void setClCode(String clCode) {
		this.clCode = clCode;
	}
	public String getClCodeNm() {
		return clCodeNm;
	}
	public void setClCodeNm(String clCodeNm) {
		this.clCodeNm = clCodeNm;
	}
	public String getClCodeId() {
		return clCodeId;
	}
	public void setClCodeId(String clCodeId) {
		this.clCodeId = clCodeId;
	}
	public String getClCodeIdNm() {
		return clCodeIdNm;
	}
	public void setClCodeIdNm(String clCodeIdNm) {
		this.clCodeIdNm = clCodeIdNm;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getLockCnt() {
		return lockCnt;
	}
	public void setLockCnt(String lockCnt) {
		this.lockCnt = lockCnt;
	}
	public String getUserDelDt() {
		return userDelDt;
	}
	public void setUserDelDt(String userDelDt) {
		this.userDelDt = userDelDt;
	}
	public String getLastLogDt() {
		return lastLogDt;
	}
	public void setLastLogDt(String lastLogDt) {
		this.lastLogDt = lastLogDt;
	}
	
}
