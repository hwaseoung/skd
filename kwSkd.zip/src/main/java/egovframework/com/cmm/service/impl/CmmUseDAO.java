package egovframework.com.cmm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.service.CmmnDetailCode;

@Repository("cmmUseDAO")
public class CmmUseDAO extends EgovComAbstractDAO {

	/**
	 * 주어진 조건에 따른 공통코드를 불러온다.
	 *
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CmmnDetailCode> selectCmmCodeDetail(ComDefaultCodeVO vo){
		return (List<CmmnDetailCode>) list("CmmUseDAO.selectCmmCodeDetail", vo);
	}

	/**
	 * 분류코드를 불러온다.
	 *
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<CmmnDetailCode> selectCmmClCode(ComDefaultCodeVO vo) {
		return (List<CmmnDetailCode>) list("CmmUseDAO.selectCmmClCode", vo);
	}
	
	/**
	 * 분류상세코드를 불러온다
	 *
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<CmmnDetailCode> selectCmmClCodeDetail(ComDefaultCodeVO vo) {
		return (List<CmmnDetailCode>) list("CmmUseDAO.selectCmmClCodeDetail", vo);
	}
}
