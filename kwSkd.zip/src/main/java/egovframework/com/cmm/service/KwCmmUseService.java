package egovframework.com.cmm.service;

import java.util.List;
import java.util.Map;

import egovframework.com.cmm.ComDefaultCodeVO;


public interface KwCmmUseService {

    /**
     * 공통코드를 조회한다.
     *
     * @param vo
     * @return List(코드)
     * @throws Exception
     */
    public List<CmmnDetailCode> selectCmmCodeDetail(ComDefaultCodeVO vo);

    /**
     * ComDefaultCodeVO의 리스트를 받아서 여러개의 코드 리스트를 맵에 담아서 리턴한다.
     *
     * @param voList
     * @return Map(코드)
     * @throws Exception
     */
    public Map<String, List<CmmnDetailCode>> selectCmmCodeDetails(List<?> voList) throws Exception;

    /**
     * 분류코드를 조회한다.
     *
     * @param vo
     * @return List(코드)
     * @throws Exception
     */
	public  List<CmmnDetailCode> selectCmmClCode(ComDefaultCodeVO vo);
	
	/**
     * 분류상세코드를 조회한다.
     *
     * @param vo
     * @return List(코드)
     * @throws Exception
     */
	public  List<CmmnDetailCode> selectCmmClCodeDetail(ComDefaultCodeVO vo) ;
}
