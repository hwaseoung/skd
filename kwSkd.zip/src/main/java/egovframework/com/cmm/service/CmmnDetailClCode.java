package egovframework.com.cmm.service;

import java.io.Serializable;

public class CmmnDetailClCode implements Serializable {

	private static final long serialVersionUID = -6508801327314181679L;

	/*
	 * 분류코드
	 */
	private String clCode = "";

	/*
	 * 분류코드
	 */
	private String clCodeNm = "";

	/*
	 * 분류코드id
	 */
	private String clCodeId = "";

	/*
	 * 분류코드id명
	 */
	private String clCodeIdNm = "";

	/*
	 * 분류코드id설명
	 */
	private String clCodeIdDc = "";

	/*
	 * 사용여부
	 */
	private String useAt = "";
	
	/*
	 * 순번
	 */
	private String clCodeIdNo = "";

	/*
	 * 최초등록자ID
	 */
	private String frstRegisterId = "";

	/*
	 * 최종수정자ID
	 */
	private String lastUpdusrId = "";

	
	public String getClCode() {
		return clCode;
	}

	public void setClCode(String clCode) {
		this.clCode = clCode;
	}

	public String getClCodeNm() {
		return clCodeNm;
	}

	public void setClCodeNm(String clCodeNm) {
		this.clCodeNm = clCodeNm;
	}

	public String getClCodeId() {
		return clCodeId;
	}

	public void setClCodeId(String clCodeId) {
		this.clCodeId = clCodeId;
	}

	public String getClCodeIdNm() {
		return clCodeIdNm;
	}

	public void setClCodeIdNm(String clCodeIdNm) {
		this.clCodeIdNm = clCodeIdNm;
	}

	public String getClCodeIdDc() {
		return clCodeIdDc;
	}

	public void setClCodeIdDc(String clCodeIdDc) {
		this.clCodeIdDc = clCodeIdDc;
	}

	public String getUseAt() {
		return useAt;
	}

	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

	public String getClCodeIdNo() {
		return clCodeIdNo;
	}

	public void setClCodeIdNo(String clCodeIdNo) {
		this.clCodeIdNo = clCodeIdNo;
	}
	
}
