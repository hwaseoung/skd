package egovframework.let.uat.uia.service.impl;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.LoginVO;
import egovframework.let.uat.uia.service.KwLoginService;
import egovframework.let.uat.uia.service.LoginLog;
import egovframework.let.utl.fcc.service.NumberUtil;
import egovframework.let.utl.fcc.service.StringUtil;
import egovframework.let.utl.sim.service.EgovFileScrty;

@Service("loginService")
public class KwLoginServiceImpl extends EgovAbstractServiceImpl implements
        KwLoginService {

    @Resource(name="loginDAO")
    private LoginDAO loginDAO;


    /**
	 * 일반 로그인을 처리한다
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    @Override
	public LoginVO actionLogin(LoginVO vo) throws Exception {

    	// 1. 입력한 비밀번호를 암호화한다.
    	String enpassword = EgovFileScrty.encryptPassword(vo.getPassword(), vo.getId());
    	vo.setPassword(enpassword);

    	// 2. 아이디와 암호화된 비밀번호가 DB와 일치하는지 확인한다.
    	LoginVO loginVO = loginDAO.actionLogin(vo);

    	// 3. 결과를 리턴한다.
    	if (loginVO != null && !loginVO.getId().equals("") && !loginVO.getPassword().equals("")) {
    		if(Integer.parseInt(loginVO.getLockCnt()) < 5 && !loginVO.getLockCnt().equals("0") ) {
    			vo.setLockCnt("0");
    			loginDAO.updateLockCnt(vo);
    		}    		
    		return loginVO;
    	} else {
    		loginDAO.updateLockCnt(vo);
    		vo.setPassword("");
    		loginVO = loginDAO.actionLogin(vo);
    		if(loginVO != null) {
    			loginVO.setId("");
    		}
    		
    	}

    	return loginVO;
    }

    /**
	 * 아이디를 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    @Override
	public LoginVO searchId(LoginVO vo) throws Exception {

    	// 1. 이름, 이메일주소가 DB와 일치하는 사용자 ID를 조회한다.
    	LoginVO loginVO = loginDAO.searchId(vo);

    	// 2. 결과를 리턴한다.
    	if (loginVO != null && !loginVO.getId().equals("")) {
    		return loginVO;
    	} else {
    		loginVO = new LoginVO();
    	}

    	return loginVO;
    }

    /**
	 * 비밀번호를 찾는다.
	 * @param vo LoginVO
	 * @return boolean
	 * @exception Exception
	 */
    @Override
	public boolean searchPassword(LoginVO vo) throws Exception {

    	boolean result = true;

    	// 1. 아이디, 이름, 이메일주소, 비밀번호 힌트, 비밀번호 정답이 DB와 일치하는 사용자 Password를 조회한다.
    	LoginVO loginVO = loginDAO.searchPassword(vo);
    	if (loginVO == null || loginVO.getPassword() == null || loginVO.getPassword().equals("")) {
    		return false;
    	}

    	// 2. 임시 비밀번호를 생성한다.(영+영+숫+영+영+숫=6자리)
    	String newpassword = "";
    	for (int i = 1; i <= 6; i++) {
    		// 영자
    		if (i % 3 != 0) {
    			newpassword += StringUtil.getRandomStr('a', 'z');
    		// 숫자
    		} else {
    			newpassword += NumberUtil.getRandomNum(0, 9);
    		}
    	}

    	// 3. 임시 비밀번호를 암호화하여 DB에 저장한다.
    	LoginVO pwVO = new LoginVO();
    	String enpassword = EgovFileScrty.encryptPassword(newpassword, vo.getId());
    	pwVO.setId(vo.getId());
    	pwVO.setPassword(enpassword);
    	pwVO.setUserSe(vo.getUserSe());
    	
    	loginDAO.updatePassword(pwVO);

    	// 4. 임시 비밀번호를 이메일 발송한다.(메일연동솔루션 활용)
    	//SndngMailVO sndngMailVO = new SndngMailVO();
    	//sndngMailVO.setDsptchPerson("webmaster");
    	//sndngMailVO.setRecptnPerson(vo.getEmail());
    	//sndngMailVO.setSj("[MOPAS] 임시 비밀번호를 발송했습니다.");
    	//sndngMailVO.setEmailCn("고객님의 임시 비밀번호는 " + newpassword + " 입니다.");
    	//sndngMailVO.setAtchFileId("");

    	//result = sndngMailRegistService.insertSndngMail(sndngMailVO);

    	return result;
    }
    
    /**
	 * 접속로그를 기록한다.
	 * 
	 * @param LoginLog
	 */
	public void logInsertLoginLog(LoginLog loinLog) throws Exception {
		//접속 로그저장
		loginDAO.logInsertLoginLog(loinLog);    	
		
		//최근접속일자 저장
    	loginDAO.updateLastLogDt(loinLog);
		
	}
	
	/**
	 * 최근접속일자 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    @Override
	public LoginVO searchLastLogDt(LoginVO vo) throws Exception {

    	// 최근접속일자 조회
    	LoginVO loginVO = loginDAO.searchLastLogDt(vo);

    	// 2. 결과를 리턴한다.
    	if (loginVO != null && !loginVO.getLastLogDt().equals("")) {
    		return loginVO;
    	} else {
    		loginVO = new LoginVO();
    	}

    	return loginVO;
    }
}
