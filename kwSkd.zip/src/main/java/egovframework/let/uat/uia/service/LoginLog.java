package egovframework.let.uat.uia.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class LoginLog implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/** 로그ID */
	private String logId;

	/** 사용자ID */
	private String loginId;

	/** 사용자명 */
	private String loginNm;

	/** 접속IP */
	private String loginIp;

	/** 접속방식 */
	private String loginMthd;

	/** 생성일시 */
	private String creatDt;

	
	public String getLogId() {
		return logId;
	}


	public void setLogId(String logId) {
		this.logId = logId;
	}


	public String getLoginId() {
		return loginId;
	}


	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}


	public String getLoginNm() {
		return loginNm;
	}


	public void setLoginNm(String loginNm) {
		this.loginNm = loginNm;
	}


	public String getLoginIp() {
		return loginIp;
	}


	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}


	public String getLoginMthd() {
		return loginMthd;
	}


	public void setLoginMthd(String loginMthd) {
		this.loginMthd = loginMthd;
	}


	public String getCreatDt() {
		return creatDt;
	}


	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}


	/**
     * toString 메소드를 대치한다.
     */
    public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }
    
}
