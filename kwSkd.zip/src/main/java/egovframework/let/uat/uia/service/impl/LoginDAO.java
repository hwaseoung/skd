package egovframework.let.uat.uia.service.impl;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.LoginVO;
import egovframework.let.uat.uia.service.LoginLog;

@Repository("loginDAO")
public class LoginDAO extends EgovAbstractMapper {

	/**
	 * 일반 로그인을 처리한다
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    public LoginVO actionLogin(LoginVO vo) throws Exception {
    	return (LoginVO)selectOne("loginDAO.actionLogin", vo);
    }

    /**
	 * 아이디를 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    public LoginVO searchId(LoginVO vo) throws Exception {

    	return (LoginVO)selectOne("loginDAO.searchId", vo);
    }

    /**
	 * 비밀번호를 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    public LoginVO searchPassword(LoginVO vo) throws Exception {

    	return (LoginVO)selectOne("loginDAO.searchPassword", vo);
    }

    /**
	 * 변경된 비밀번호를 저장한다.
	 * @param vo LoginVO
	 * @exception Exception
	 */
    public void updatePassword(LoginVO vo) throws Exception {
    	update("loginDAO.updatePassword", vo);
    }

    /**
	 * 접속로그를 기록한다.
	 *
	 * @param LoginLog
	 * @return
	 * @throws Exception
	 */
	public void logInsertLoginLog(LoginLog loinLog) throws Exception {
		insert("loginDAO.logInsertLoginLog", loinLog);
		
	}
	
	/**
	 * 최종접속일자 기록한다.
	 *
	 * @param LoginLog
	 * @return
	 * @throws Exception
	 */

	public void updateLastLogDt(LoginLog loinLog) throws Exception {
		insert("loginDAO.updateLastLogDt", loinLog);
		
	}
	
	 /**
	 * 최종접속일자 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    public LoginVO searchLastLogDt(LoginVO vo) throws Exception {

    	return (LoginVO)selectOne("loginDAO.searchLastLogDt", vo);
    }
    
    /**
   	 * 잠금횟수 저장한다
   	 * @param vo LoginVO
   	 * @exception Exception
   	 */
       public void updateLockCnt(LoginVO vo) throws Exception {
       	update("loginDAO.updateLockCnt", vo);
       }
}
