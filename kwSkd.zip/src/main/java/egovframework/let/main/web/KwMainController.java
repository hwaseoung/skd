package egovframework.let.main.web;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.let.utl.fcc.service.DateUtil;

@Controller@SessionAttributes(types = ComDefaultVO.class)
public class KwMainController {

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;


	/**
	 *  메인 페이지 조회
	 * @return 메인페이지 정보 Map [key : 항목명]
	 *
	 * @param request
	 * @param model
	 * @exception Exception Exception
	 */
	@RequestMapping(value = "/cmm/main/mainPage.do")
	public String getMgtMainPage(HttpServletRequest request, @RequestParam Map<String, Object> commandMap, ModelMap model)
	  throws Exception{
		
    	return "redirect:/skd/scheduleView.do";
	}

	
	
	/**
     * Header Page를 조회한다.
     * @param 
     * @return 출력페이지정보 "KwIncHeader"
     * @exception Exception
     */
    @RequestMapping(value="/sym/mms/KwHeader.do")
    public String selectHeader(
    		ModelMap model)
            throws Exception {

    	return "main/inc/KwIncHeader"; 

    }

    /**
     * 좌측메뉴를 조회한다.
     * @param 
     * @return 출력페이지정보 "KwIncLeftmenu"
     * @exception Exception
     */
    @RequestMapping(value="/sym/mms/KwMenuLeft.do")
    public String selectMenuLeft(ModelMap model) throws Exception {

      	return "main/inc/KwIncLeftmenu";
    }

}