package egovframework.let.skd.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.skd.service.Holiday;
import egovframework.let.skd.service.Schedule;
import egovframework.let.skd.service.ScheduleDefaultVO;
import egovframework.let.skd.service.ScheduleSmsVO;


@Repository("KwScheduleDAO")
public class KwScheduleDAO extends EgovAbstractMapper {



	 /**
	 * 일정관리 목록 조회 캘린더
	 * @param Schedule
	 * @throws Exception
	 */
	public List<Map<String, Object>> scheduleList(Schedule scheduleVO) throws Exception {
		return  selectList("KwScheduleDAO.scheduleList", scheduleVO);
	}

	 /**
	 * 일정관리 상세 조회
	 * @param Schedule
	 * @throws Exception
	 */	
	public Schedule selectSchdule(String schduleId) throws Exception{
		return (Schedule) selectOne("KwScheduleDAO.selectSchdule", schduleId);
	}

	 /**
	 * 일정관리 등록
	 * @param Schedule
	 * @throws Exception
	 */
	public String scheduleInsert(Schedule schedule) throws Exception{
		insert("KwScheduleDAO.scheduleInsert", schedule);
		
		String str = schedule.getSchdulId(); 
		return str;
	}

	 /**
	 * 일정관리 수정
	 * @param Schedule
	 * @throws Exception
	 */
	public void scheduleUpdate(Schedule schedule) throws Exception{
		update("KwScheduleDAO.scheduleUpdate", schedule);
		
	}

	 /**
	 * 일정관리 삭제
	 * @param Schedule
	 * @throws Exception
	 */
	public void scheduleRemove(Schedule schedule) throws Exception{
		delete("KwScheduleDAO.scheduleRemove", schedule);
		
	}

	 /**
	 * 일정관리 목록 조회 리스트
	 * @param Schedule
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public List<?> scheduleList(ScheduleDefaultVO scheduleVO) throws Exception{
		return list("KwScheduleDAO.scheduleList_S", scheduleVO);
	}	
	
	 /**
	 * 일정관리 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */	
	public int scheduleListTotCnt(ScheduleDefaultVO scheduleVO) throws Exception{
	       return (Integer)selectOne("KwScheduleDAO.scheduleListTotCnt_S", scheduleVO);
	}

	 /**
	 * 일정관리 sms발송 저장
	 * @param Schedule
	 * @throws Exception
	 */
	public String scheduleSmsInsert(ScheduleSmsVO smsVO) throws Exception{
		 insert("KwScheduleDAO.scheduleSmsInsert", smsVO);
	 
		 String str = smsVO.getSmsId();
	 
		 return str;
		 
	}

	 /**
	 * 일정관리 수정 이력 저장
	 * @param Schedule
	 * @throws Exception
	 */
	public void insertSchdulHistory(Schedule schedule) throws Exception{
		insert("KwScheduleDAO.insertSchdulHistory", schedule);
		
	}

	 /**
	 * 일정관리 삭제
	 * @param Schedule
	 * @throws Exception
	 */
	public void smsRemove(Schedule schedule) throws Exception{
		delete("KwScheduleDAO.smsRemove", schedule);
		
	}

	 /**
	 * 일정smsId 저장
	 * @param Schedule
	 * @throws Exception
	 */
	public void scheduleSmsIdInsert(Schedule schedule) throws Exception{
		insert("KwScheduleDAO.scheduleSmsIdInsert", schedule);
		
	}

	 /**
	 * 일정smsId 저장
	 * @param Schedule
	 * @throws Exception
	 */
	public void scheduleSmsIdRemove(Schedule schedule) throws Exception{
		delete("KwScheduleDAO.scheduleSmsIdRemove", schedule);
		
	}
	
	/**
	 * 일정 알림일시 목록
	 * @param Schedule
	 * @throws Exception
	 */	
	@SuppressWarnings("deprecation")
	public List<?> selectSmsList(ScheduleDefaultVO searchVO) {
		return list("KwScheduleDAO.selectSmsList", searchVO);
	}

	/**
	 * 일정 알림일시 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */	
	public int selectSmsListTotCnt(ScheduleDefaultVO searchVO) {
		return (Integer)selectOne("KwScheduleDAO.selectSmsListTotCnt", searchVO);
	}

	/**
	 * 일정 작업구분 대상자목록
	 * @param Schedule
	 * @throws Exception
	 */	
	public List<Map<String, Object>> groupList(Schedule schedule) {
		return  selectList("KwScheduleDAO.groupList", schedule);
	}

	/**
	 * 일정주기 등록
	 * @param Schedule
	 * @throws Exception
	 */	
	public void scheduleFreqInsert(Schedule schedule) {
		insert("KwScheduleDAO.scheduleFreqInsert", schedule);
		
	}

	/**
	 * 일정주기 삭제
	 * @param Schedule
	 * @throws Exception
	 */	
	public void scheduleFreqRemove(Schedule schedule) {
		delete("KwScheduleDAO.scheduleFreqRemove", schedule);
		
	}
	
	/**
	 * 일정주기 특정일정 수정
	 * @param Schedule
	 * @throws Exception
	 */	
	public void scheduleFreqUpdate(Schedule schedule) {
		update("KwScheduleDAO.scheduleFreqUpdate", schedule);
		
	}
	
	/**
	 * 일정주기 목록
	 * @param Schedule
	 * @throws Exception
	 */	
	@SuppressWarnings("deprecation")
	public List<?> selectFreqList(ScheduleDefaultVO searchVO) {
		return list("KwScheduleDAO.selectFreqList", searchVO);
	}

	/**
	 * 일정주기 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */	
	public int selectFreqListTotCnt(ScheduleDefaultVO searchVO) {
		return (Integer)selectOne("KwScheduleDAO.selectFreqListTotCnt", searchVO);
	}

	/**
	 * 공휴일 저장
	 * @param Holiday
	 * @throws Exception
	 */	
	public void holidayInsert(Holiday holiday) {
		insert("KwScheduleDAO.holidayInsert", holiday);
		
	}
	
	/**
	 * 공휴일 조회
	 * @param Holiday
	 * @throws Exception
	 */	
	public List<Map<String, Object>> holidayList(Schedule scheduleVO) {
		return  selectList("KwScheduleDAO.holidayList", scheduleVO);
	}

	/**
	 * 공휴일 전체 삭제
	 * @param Holiday
	 * @throws Exception
	 */	
	public void holidayDelete() {
		delete("KwScheduleDAO.holidayDelete");
		
	}
	
	/**
	 * 공휴일 존재여부
	 * @param Holiday
	 * @throws Exception
	 */	
	public int holidayCnt() {
		return (Integer)selectOne("KwScheduleDAO.holidayCnt");
	}

	
}
