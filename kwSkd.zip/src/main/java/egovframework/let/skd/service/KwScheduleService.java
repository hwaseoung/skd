package egovframework.let.skd.service;

import java.util.List;
import java.util.Map;

import egovframework.com.cmm.ComDefaultVO;

public interface KwScheduleService {

	/**
	 * 일정관리 목록 조회 캘린더
	 * @param Schedule
	 * @throws Exception
	 */
	List<Map<String, Object>> scheduleList(Schedule scheduleVO) throws Exception;
	

	/**
	 * 일정관리 상세조회
	 * @param Schedule
	 * @throws Exception
	 */
	Schedule selectSchdule(String schduleId) throws Exception;

	/**
	 * 일정관리 등록
	 * @param Schedule
	 * @throws Exception
	 */
	void scheduleInsert(Schedule schedule) throws Exception;

	/**
	 * 일정관리 수정
	 * @param Schedule
	 * @throws Exception
	 */
	void scheduleUpdate(Schedule schedule) throws Exception;

	/**
	 * 일정관리 삭제
	 * @param Schedule
	 * @throws Exception
	 */
	void scheduleRemove(Schedule schedule) throws Exception;

	/**
	 * 일정관리 목록조회 리스트
	 * @param Schedule
	 * @throws Exception
	 */
	 List<?> scheduleList(ScheduleDefaultVO scheduleVO) throws Exception;

	 /**
	 * 일정관리 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */
	int scheduleListTotCnt(ScheduleDefaultVO scheduleVO) throws Exception;

	 /**
	 * 일정관리 수정 이력 저장
	 * @param Schedule
	 * @throws Exception
	 */
	void insertSchdulHistory(Schedule schedule)throws Exception;

	 /**
	 * 일정 알림일시 목록
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	List<?> selectSmsList(ScheduleDefaultVO searchVO) throws Exception;
	
	
	/**
	 * 일정 알림일시 목록 총건수
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	int selectSmsListTotCnt(ScheduleDefaultVO searchVO) throws Exception;

	 /**
	 * 일정주기 목록
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	List<?> selectFreqList(ScheduleDefaultVO searchVO)throws Exception;

	/**
	 * 일정주기 목록 총건수
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	int selectFreqListTotCnt(ScheduleDefaultVO searchVO)throws Exception;

	/**
	 * 공휴일 조회
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	List<Map<String, Object>> holidayList(Schedule scheduleVO)throws Exception;

	/**
	 * 공휴일 조회
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	void getHolidayService()throws Exception;

	/**
	 * 올해년도 공휴일 존재여부
	 * @param ComDefaultVO
	 * @throws Exception
	 */
	int holidayCnt();


}
