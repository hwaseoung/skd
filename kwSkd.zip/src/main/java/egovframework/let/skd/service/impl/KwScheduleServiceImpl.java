package egovframework.let.skd.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.LoginVO;
import egovframework.let.batch.service.OpenApi;
import egovframework.let.skd.service.Holiday;
import egovframework.let.skd.service.KwScheduleService;
import egovframework.let.skd.service.Schedule;
import egovframework.let.skd.service.ScheduleDefaultVO;
import egovframework.let.skd.service.ScheduleSmsVO;
import egovframework.let.utl.fcc.service.DateUtil;
import egovframework.let.utl.fcc.service.StringUtil;

@Service("KwScheduleService")
public class KwScheduleServiceImpl extends EgovAbstractServiceImpl implements KwScheduleService {

    @Resource(name="KwScheduleDAO")
    private KwScheduleDAO kwScheduleDAO;
    private final OpenApi openApi = new OpenApi();


    /**
   	 * 일정관리 목록 캘린더
   	 * @param Schedule
   	 * @throws Exception
   	 */
	@Override
	public List<Map<String, Object>> scheduleList(Schedule scheduleVO) throws Exception {
        return kwScheduleDAO.scheduleList(scheduleVO);
	}

	 /**
	 * 일정관리 상세 조회
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public Schedule selectSchdule(String schduleId) throws Exception{
		Schedule vo = kwScheduleDAO.selectSchdule(schduleId);
		return vo;
	}
	
	 /**
	 * 일정관리 등록
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public void scheduleInsert(Schedule schedule) throws Exception{
		//일정등록
		String str = kwScheduleDAO.scheduleInsert(schedule);
		
		//sms 등록
		schedule.setSchdulId(str);
		schedule.setCheckYn(true);
		scheduleSmS(schedule);
	}
	
	 /**
	 * 일정관리 수정
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public void scheduleUpdate(Schedule schedule) throws Exception{
		
		//수정
		if(schedule.getSchdulFreqSn().equals("")) {
			kwScheduleDAO.scheduleUpdate(schedule);
			//일정주기 삭제
			kwScheduleDAO.scheduleFreqRemove(schedule);
			//sms 등록
			scheduleSmS(schedule);
			
		}else {
			//일정주기 시작일자
			schedule.setSchdulFreqBgnDt(schedule.getSchdulBgnDt());
			if(schedule.isCheckYn()) {
				//일정주기 삭제
				kwScheduleDAO.scheduleFreqRemove(schedule);
				//sms등록
				scheduleSmS(schedule);
			}else {
				kwScheduleDAO.scheduleFreqUpdate(schedule);
			}
		}
	}
	
	/**
	 * 일정 sms 등록
	 * @param Schedule
	 * @throws Exception
	 */
	 private void scheduleSmS(Schedule schedule) throws Exception{
		///관리자, 담당자 번호가 존재시 기타가 아닌 경우는 시간 고정 08:30분
		ScheduleSmsVO smsVO = new ScheduleSmsVO();
		smsVO.setSendSe(schedule.getSendSe()); //알림구분
		if(schedule.getSendSe().equals("ETC")) {
			smsVO.setReqTime(schedule.getSendDt()); //알림일시
		}else {
			smsVO.setReqTime(StringUtil.cutString(schedule.getSchdulBgnDt(), 10)+" 08:30:00"); //알림일시
		}
		schedule.setSendDt(smsVO.getReqTime());
		smsVO.setSubject(schedule.getSchdulSj());//제목
		smsVO.setMsg("일정알림 : "+schedule.getSchdulSj());//내용
		if(!schedule.getSendSe().equals("") && schedule.getSendSe() != null && schedule.isCheckYn()) {
			//sms 삭제
			kwScheduleDAO.smsRemove(schedule);
			//일정smsid 삭제
			kwScheduleDAO.scheduleSmsIdRemove(schedule);
			
			if(schedule.getSchdulAdminTelNo() != null && !schedule.getSchdulAdminTelNo().equals("")) {
				//관리자 sms등록
				smsVO.setCallName(schedule.getSchdulAdminNm()); //수신자
				smsVO.setCallPhone(schedule.getSchdulAdminTelNo()); //수신자번호
				schedule.setSendTrpr(schedule.getSchdulAdminNm());
				String sms = null;
				//일정주기가 없을경우
				if(schedule.getSchdulFreq().equals("")) {
					sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
					schedule.setSchdulSmsId(sms);
					schedule.setSchdulFreqSn("0");
					kwScheduleDAO.scheduleSmsIdInsert(schedule);
				}else if(!schedule.getSchdulFreqSn().equals("") && schedule.getSchdulFreqSn()!=null){
					sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
					schedule.setSchdulSmsId(sms);
					kwScheduleDAO.scheduleSmsIdInsert(schedule);
					kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
				}else {
					scheduleSmsId(schedule, smsVO, null, "Y", false);
				}
			}
			
			if(schedule.getSchdulChargerTelNo() != null && !schedule.getSchdulChargerTelNo().equals("")) {
				//담당자 sms등록
				smsVO.setCallName(schedule.getSchdulChargerNm()); //수신자
				smsVO.setCallPhone(schedule.getSchdulChargerTelNo()); //수신자번호
				schedule.setSendTrpr(schedule.getSchdulChargerNm());
				String sms= null;
				if(schedule.getSchdulFreq().equals("")) {
					sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
					schedule.setSchdulSmsId(sms);
					schedule.setSchdulFreqSn("0");
					kwScheduleDAO.scheduleSmsIdInsert(schedule);
				}//일정주기가 존재하면서 일정주기일련번호 존재
				else if(!schedule.getSchdulFreqSn().equals("") && schedule.getSchdulFreqSn()!=null){
					sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
					schedule.setSchdulSmsId(sms);
					kwScheduleDAO.scheduleSmsIdInsert(schedule);
					if(schedule.getSchdulAdminTelNo().equals("")) {
						kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
					}
				}else {
					//일정주기 등록
					scheduleSmsId(schedule, smsVO, null, "N", false);
				}
			}else if(schedule.getSchdulChargerNm().equals("group")) {
				List<Map<String, Object>> list = kwScheduleDAO.groupList(schedule);
				String sms= null;
				if(schedule.getSchdulFreq().equals("")) {
					for(int i=0; i < list.size(); i++) {
						smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
						smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
						schedule.setSendTrpr(list.get(i).get("userNm").toString());
						sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
						schedule.setSchdulSmsId(sms);
						schedule.setSchdulFreqSn("0");
						kwScheduleDAO.scheduleSmsIdInsert(schedule);
					}
					
				}//일정주기가 존재하면서 일정주기 일련번호가 존재할 경우
				else if(!schedule.getSchdulFreqSn().equals("") && schedule.getSchdulFreqSn()!=null){
					for(int i=0; i < list.size(); i++) {
						smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
						smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
						schedule.setSendTrpr(list.get(i).get("userNm").toString());
						sms = kwScheduleDAO.scheduleSmsInsert(smsVO);
						schedule.setSchdulSmsId(sms);
						kwScheduleDAO.scheduleSmsIdInsert(schedule);
					}
					if(schedule.getSchdulAdminTelNo().equals("")) {
						kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
					}
				}//일정주기가 존재할경우 
				else {
					//일정주기 등록
					scheduleSmsId(schedule, smsVO, list,"N", false);
				}
			}
			
		}else {
			//일정주기 등록
			scheduleSmsId(schedule, smsVO, null,"Y", true);
		}
		
	}

	 /**
	 * 일정 smsId 등록
	 * @param list 
	 * @param Schedule
	 * @throws Exception
	 */
	private void scheduleSmsId(Schedule schedule, ScheduleSmsVO smsVO, List<Map<String, Object>> list, String yN, Boolean flag) throws Exception{
		int num = 1;
		if(!schedule.getSchdulInterval().equals("")) {
			num = Integer.parseInt(schedule.getSchdulInterval());
		}
		String sendDt = schedule.getSendDt();//발송일자 초기값
		String newDt = sendDt;//새로운 발송일자
		String startDt = schedule.getSchdulBgnDt();//시작일시 초기값
		String newStartDt = startDt;//새로운 시작일시
		String newTm = newDt.substring(11, newDt.length());
		String sms = null;
		if(schedule.getSchdulFreq().equals("weekly")) {
			for ( int j=0, cnt = 0; cnt <= j; cnt++) {
				//시작일자 및 알림일자가 종료일자보다 작으면 스톱
				 if ( DateUtil.getDaysDiff(DateUtil.addDay(StringUtil.cutString(startDt, 10),7*num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0
						  || DateUtil.getDaysDiff(DateUtil.addDay(StringUtil.cutString(sendDt, 10),7*num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0) {
					 schedule.setSendDt(sendDt);
					 schedule.setSchdulFreqSn("");
					 break;
				 }
				 j = 1+cnt;
				 newDt = DateUtil.formatDate(DateUtil.addDay(StringUtil.cutString(sendDt, 10),7*num*cnt), "-")+" "+newTm;
				 newStartDt = DateUtil.formatDate(DateUtil.addDay(StringUtil.cutString(startDt, 10),7*num*cnt), "-");
				 if(schedule.getAllDay().equals("false")) {
					 newStartDt = newStartDt +" "+ startDt.substring(11, 16);
				 }
				 schedule.setSchdulFreqBgnDt(newStartDt);
				 schedule.setSendDt(newDt);
				 smsVO.setReqTime(newDt);
				 schedule.setSchdulFreqSn(Integer.toString(cnt));	
				 if(yN.equals("Y")) {//중복등록 방지 관리리일경우만
					kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
				 }
				if(!flag) {//알림대상자가 여러명일 경우
					if(list != null) {
						 for(int i=0; i < list.size(); i++) {
							 smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
							 smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
							 schedule.setSendTrpr(list.get(i).get("userNm").toString());
							 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS 등록
							 schedule.setSchdulSmsId(sms);
							 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정SMS등록
						 }
						 
					 }else {
						 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS등록
						 schedule.setSchdulSmsId(sms);
						 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정 SMS 등록
					 }
				}
			}
			
		}else if(schedule.getSchdulFreq().equals("monthly")) {
			for ( int j=0, cnt = 0; cnt <= j; cnt++) {
				//시작일자 및 알림일자가 종료일자보다 작으면 스톱
				 if ( DateUtil.getDaysDiff(DateUtil.addMonth(StringUtil.cutString(startDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0
						 || DateUtil.getDaysDiff(DateUtil.addMonth(StringUtil.cutString(sendDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0) {
					 schedule.setSendDt(sendDt);
					 schedule.setSchdulFreqSn("");
					 break;
				 }
				 j = 1+cnt;
				
				newDt = DateUtil.formatDate(DateUtil.convertWeekDate(DateUtil.addMonth(StringUtil.cutString(sendDt, 10),num*cnt)), "-")+" "+newTm;
				newStartDt = DateUtil.formatDate(DateUtil.convertWeekDate(DateUtil.addMonth(StringUtil.cutString(startDt, 10),num*cnt)), "-");
				if(schedule.getAllDay().equals("false")) {
					 newStartDt = newStartDt +" "+ startDt.substring(11, 16);
				 }
				schedule.setSchdulFreqBgnDt(newStartDt);
				schedule.setSendDt(newDt);
				smsVO.setReqTime(newDt);
				schedule.setSchdulFreqSn(Integer.toString(cnt));	
				if(yN.equals("Y")) {//중복등록 방지 관리리일경우만
					kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
				 }
				if(!flag) {
					if(list != null) {
						 for(int i=0; i < list.size(); i++) {
							 smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
							 smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
							 schedule.setSendTrpr(list.get(i).get("userNm").toString());
							 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS 등록
							 schedule.setSchdulSmsId(sms);
							 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정SMS등록
						 }
						 
					 }else {
						 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS등록
						 schedule.setSchdulSmsId(sms);
						 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정 SMS 등록
					 }
				}
			}
			
			
		}else if(schedule.getSchdulFreq().equals("yearly")) {
			for ( int j=0, cnt = 0; cnt <= j; cnt++) {
				//시작일자 및 알림일자가 종료일자보다 작으면 스톱
				 if ( DateUtil.getDaysDiff(DateUtil.addYear(StringUtil.cutString(startDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0
						 || DateUtil.getDaysDiff(DateUtil.addYear(StringUtil.cutString(sendDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0) {
					 schedule.setSendDt(sendDt);
					 schedule.setSchdulFreqSn("");
					 break;
				 }
				 j = 1+cnt;
				 
				newDt = DateUtil.formatDate(DateUtil.convertWeekDate(DateUtil.addYear(StringUtil.cutString(sendDt, 10),num*cnt)), "-")+" "+newTm;
				newStartDt = DateUtil.formatDate(DateUtil.convertWeekDate(DateUtil.addYear(StringUtil.cutString(startDt, 10),num*cnt)), "-");
				if(schedule.getAllDay().equals("false")) {
					 newStartDt = newStartDt +" "+ startDt.substring(11, 16);
				 }
				schedule.setSchdulFreqBgnDt(newStartDt);
				schedule.setSendDt(newDt);
				smsVO.setReqTime(newDt);
				schedule.setSchdulFreqSn(Integer.toString(cnt));	
				if(yN.equals("Y")) {//중복등록 방지 관리리일경우만
					kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
				 }
				if(!flag) {
					if(list != null) {
						 for(int i=0; i < list.size(); i++) {
							 smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
							 smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
							 schedule.setSendTrpr(list.get(i).get("userNm").toString());
							 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS 등록
							 schedule.setSchdulSmsId(sms);
							 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정SMS등록
						 }
						 
					 }else {
						 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS등록
						 schedule.setSchdulSmsId(sms);
						 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정 SMS 등록
					 }
				}
			}
			
		}else if(schedule.getSchdulFreq().equals("daily")){
			for ( int j=0, cnt = 0; cnt <= j; cnt++) {
				//시작일자 및 알림일자가 종료일자보다 작으면 스톱
				 if ( DateUtil.getDaysDiff(DateUtil.addDay(StringUtil.cutString(startDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0
						 || DateUtil.getDaysDiff(DateUtil.addDay(StringUtil.cutString(sendDt, 10),num*cnt), StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0) {
					 schedule.setSendDt(sendDt);
					 schedule.setSchdulFreqSn("");
					 break;
				 }
				 j = 1+cnt;
				//일정이 주말이면서 cnt 0보다 크면
				if(DateUtil.convertWeekInt(DateUtil.addDay(StringUtil.cutString(newStartDt, 10),num)) > 0 && cnt > 0) {
					newDt= DateUtil.convertWeekDate(DateUtil.addDay(StringUtil.cutString(newStartDt, 10),num));
					newStartDt = DateUtil.convertWeekDate(DateUtil.addDay(StringUtil.cutString(newStartDt, 10),num));
					
				}//cnt 0보다 크면
				else if(cnt > 0){
					newDt = DateUtil.addDay(StringUtil.cutString(newDt, 10),num);
					newStartDt = DateUtil.addDay(StringUtil.cutString(newStartDt, 10),num);
					
				}//일정 시작일자
				else {
					newDt = DateUtil.addDay(StringUtil.cutString(newDt, 10),num*cnt);
					newStartDt = DateUtil.addDay(StringUtil.cutString(newStartDt, 10),num*cnt);
				}
				
				newDt = DateUtil.formatDate(newDt,"-")+" "+newTm;
				newStartDt = DateUtil.formatDate(newStartDt, "-");
				if(DateUtil.getDaysDiff(StringUtil.cutString(newStartDt,10),StringUtil.cutString(schedule.getSchdulEndDt(), 10)) < 0) {
					schedule.setSendDt(sendDt);
					schedule.setSchdulFreqSn("");
					break;
				}
				if(schedule.getAllDay().equals("false")) {
					 newStartDt = newStartDt +" "+ startDt.substring(11, 16);
				 }
				schedule.setSchdulFreqBgnDt(newStartDt);
				schedule.setSendDt(newDt);
				smsVO.setReqTime(newDt);
				schedule.setSchdulFreqSn(Integer.toString(cnt));	
				if(yN.equals("Y")) {//중복등록 방지 관리리일경우만
					kwScheduleDAO.scheduleFreqInsert(schedule);//일정주기 등록
				 }
				if(!flag) {
					if(list != null) {
						 for(int i=0; i < list.size(); i++) {
							 smsVO.setCallName(list.get(i).get("userNm").toString()); //수신자
							 smsVO.setCallPhone(list.get(i).get("userTelno").toString()); //수신자번호
							 schedule.setSendTrpr(list.get(i).get("userNm").toString());
							 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS 등록
							 schedule.setSchdulSmsId(sms);
							 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정SMS등록
						 }
						 
					 }else {
						 sms = kwScheduleDAO.scheduleSmsInsert(smsVO);//SMS등록
						 schedule.setSchdulSmsId(sms);
						 kwScheduleDAO.scheduleSmsIdInsert(schedule);//일정 SMS 등록
					 }
				}
			}
		}
	}
		 
	/**
	 * 일정관리 삭제
	 * @param Schedule
	 * @throws Exception
	 */	
	@Override
	public void scheduleRemove(Schedule schedule) throws Exception {
		
		//sms 삭제
		kwScheduleDAO.smsRemove(schedule);
		
		//일정smsid 삭제
		kwScheduleDAO.scheduleSmsIdRemove(schedule);
		
		//일정주기 삭제
		kwScheduleDAO.scheduleFreqRemove(schedule);
		
		if(schedule.getSchdulFreqSn().equals("")) {
			//일정 수정시 히스토리 정보를 등록한다.
			kwScheduleDAO.insertSchdulHistory(schedule);
			
			//일정 삭제
			kwScheduleDAO.scheduleRemove(schedule);
		}
		
	}
	
	 /**
	 * 일정관리 목록 조회 리스트
	 * @param Schedule
	 * @throws Exception
	 */	
	@Override
	public List<?> scheduleList(ScheduleDefaultVO scheduleVO) throws Exception {
		List<?> result = kwScheduleDAO.scheduleList(scheduleVO);
		return result;
	}
	
	 /**
	 * 일정관리 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public int scheduleListTotCnt(ScheduleDefaultVO scheduleVO) throws Exception {
		return kwScheduleDAO.scheduleListTotCnt(scheduleVO);
	}
	
	 /**
	 * 일정관리 수정 이력 저장
	 * @param Schedule
	 * @throws Exception
	 */	
	@Override
	public void insertSchdulHistory(Schedule schedule) throws Exception{
		kwScheduleDAO.insertSchdulHistory(schedule);
	}
	
	 /**
	 * 일정 알림일시 목록 
	 * @param Schedule
	 * @throws Exception
	 */	
	@Override
	public List<?> selectSmsList(ScheduleDefaultVO searchVO) throws Exception {
		List<?> result = kwScheduleDAO.selectSmsList(searchVO);
		return result;
	}
	
	 /**
	 * 일정 알림일시 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public int selectSmsListTotCnt(ScheduleDefaultVO searchVO) throws Exception {
		return kwScheduleDAO.selectSmsListTotCnt(searchVO);
	}
	

	 /**
	 * 일정주기 목록 
	 * @param Schedule
	 * @throws Exception
	 */	
	@Override
	public List<?> selectFreqList(ScheduleDefaultVO searchVO) throws Exception {
		List<?> result = kwScheduleDAO.selectFreqList(searchVO);
		return result;
	}
	
	 /**
	 * 일정주기 목록 총건수
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public int selectFreqListTotCnt(ScheduleDefaultVO searchVO) throws Exception {
		return kwScheduleDAO.selectFreqListTotCnt(searchVO);
	}
	
	 /**
   	 * 공휴일 조회
   	 * @param Schedule
   	 * @throws Exception
   	 */
	@Override
	public List<Map<String, Object>> holidayList(Schedule scheduleVO) throws Exception {
        return kwScheduleDAO.holidayList(scheduleVO);
	}
	
	@Override
	public void getHolidayService() throws Exception{
		List<Holiday> holidayList = new ArrayList<>();
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
	    String solYear = String.valueOf(LocalDate.now().getYear());
	    for (int solMonth = 1; solMonth <= 12; solMonth++) {
	        // 숫자 2자리 맞춤
	        String strMonth = String.valueOf(solMonth);
	        while (strMonth.length() < 2) {
	            strMonth = "0" + strMonth;
	        }
	        
	        JSONObject jsonData = openApi.getHolidayApi(solYear, strMonth, "holiday");
	        JSONObject body = jsonData.getJSONObject("response").getJSONObject("body");
	
	        if (body.getInt("totalCount") != 0) {
	            // 공휴일 값이 하나일 때는 item이 jsonObject로 받아지기 때문에 조건문 사용
	            if (body.getInt("totalCount") == 1) {
	            	Holiday holiday = new Holiday();
	                JSONObject item = body.getJSONObject("items").getJSONObject("item");
                	holiday.setHolidayDate(String.valueOf(item.getInt("locdate")));
                	holiday.setHolidayName(item.getString("dateName"));
                	holiday.setIsHoliday(item.getString("isHoliday"));
                	holidayList.add(holiday);
	            } else {
	                JSONArray items = body.getJSONObject("items").getJSONArray("item");
	                for (int i=0; i < items.length(); i++ ) { // 해당 월 공휴일 갯수
	                	Holiday holiday = new Holiday();
	                	JSONObject map = items.getJSONObject(i);
                    	holiday.setHolidayDate(String.valueOf(map.getInt("locdate")));
                    	holiday.setHolidayName(map.getString("dateName"));
                    	holiday.setIsHoliday(map.getString("isHoliday"));
                        holidayList.add(holiday);
	                }
	            }
	        }
	        
	        if (solYear.equals(String.valueOf(LocalDate.now().getYear())) && solMonth == 12) {
	            // 내년까지 저장
	            solYear = String.valueOf(LocalDate.now().plusYears(1).getYear());
	            solMonth = 1;
	        }
	    }
	    if (!holidayList.isEmpty()) {
	    	//기존 공휴일 삭제 후 저장
	    	kwScheduleDAO.holidayDelete();
	    	
	    	// 공휴일 저장
	    	 Holiday holiday = new Holiday();
	    	 holiday.setFrstRegisterId(loginVO.getId());
	    	 for(int i=0; i < holidayList.size(); i++) {
	    		 holiday.setHolidayDate(DateUtil.formatDate(holidayList.get(i).getHolidayDate(),"-"));
	    		 holiday.setHolidayName(holidayList.get(i).getHolidayName());
	    		 holiday.setIsHoliday(holidayList.get(i).getIsHoliday());
	    		 kwScheduleDAO.holidayInsert(holiday);
	    	 }
        }
	}
	
	/**
	 * 올해년도 공휴일 존재여부
	 * @param Schedule
	 * @throws Exception
	 */
	@Override
	public int holidayCnt(){
		return kwScheduleDAO.holidayCnt();
	}
}
