package egovframework.let.skd.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class  Schedule implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/** 일정ID*/
	private String schdulId ;
	/** 제목*/
    private String schdulSj ;
    /** 내용*/
    private String schdulCn ;
    /** 시작일자*/
    private String schdulBgnDt ;
    /** 종료일자*/
    private String schdulEndDt ;
    /** 종일여부*/
    private String allDay ;
    /** 색상*/
    private String schdulClr ;
    /** 알림구분*/
    private String sendSe ;
    /** 알림일자*/
    private String sendDt ;
    /** 작업구분*/
    private String clCode ;
    /** 작업상세구분*/
    private String clCodeId ;
    /** 관리자*/
    private String schdulAdminNm ;
    /** 관리자번호*/
    private String schdulAdminTelNo ;
    /** 담당자*/
    private String schdulChargerNm ;
    /** 담당자번호*/
    private String schdulChargerTelNo ;
    /** 등록자*/
    private String frstRegisterId ;
    /** 수정자*/
    private String lastUpdusrId   ;
    /** 페이지구분*/
    private String pageTy   ;
    /** 재알림여부*/
    private boolean checkYn   ;
    /** 일정주기*/
    private String schdulFreq   ;
    /** 일정간격*/
    private String schdulInterval   ;
    /** 일정sms아이디*/
    private String schdulSmsId   ;
    /** 수정 권한*/
    private String updateAuth;
    /** 발송대상자*/
    private String sendTrpr;
    /** 일정주기 일련번호*/
    private String schdulFreqSn;
    /** 일정시작일시*/
    private String schdulFreqBgnDt;
   
    
	public String getSchdulId() {
		return schdulId;
	}
	public void setSchdulId(String schdulId) {
		this.schdulId = schdulId;
	}
	public String getSchdulSj() {
		return schdulSj;
	}
	public void setSchdulSj(String schdulSj) {
		this.schdulSj = schdulSj;
	}
	public String getSchdulCn() {
		return schdulCn;
	}
	public void setSchdulCn(String schdulCn) {
		this.schdulCn = schdulCn;
	}
	public String getSchdulBgnDt() {
		return schdulBgnDt;
	}
	public void setSchdulBgnDt(String schdulBgnDt) {
		this.schdulBgnDt = schdulBgnDt;
	}
	public String getSchdulEndDt() {
		return schdulEndDt;
	}
	public void setSchdulEndDt(String schdulEndDt) {
		this.schdulEndDt = schdulEndDt;
	}
	public String getAllDay() {
		return allDay;
	}
	public void setAllDay(String allDay) {
		this.allDay = allDay;
	}
	public String getSchdulClr() {
		return schdulClr;
	}
	public void setSchdulClr(String schdulClr) {
		this.schdulClr = schdulClr;
	}
	public String getSendSe() {
		return sendSe;
	}
	public void setSendSe(String sendSe) {
		this.sendSe = sendSe;
	}
	public String getSendDt() {
		return sendDt;
	}
	public void setSendDt(String sendDt) {
		this.sendDt = sendDt;
	}
	public String getClCode() {
		return clCode;
	}
	public void setClCode(String clCode) {
		this.clCode = clCode;
	}
	public String getClCodeId() {
		return clCodeId;
	}
	public void setClCodeId(String clCodeId) {
		this.clCodeId = clCodeId;
	}
	public String getSchdulAdminNm() {
		return schdulAdminNm;
	}
	public void setSchdulAdminNm(String schdulAdminNm) {
		this.schdulAdminNm = schdulAdminNm;
	}
	public String getSchdulAdminTelNo() {
		return schdulAdminTelNo;
	}
	public void setSchdulAdminTelNo(String schdulAdminTelNo) {
		this.schdulAdminTelNo = schdulAdminTelNo;
	}
	public String getSchdulChargerNm() {
		return schdulChargerNm;
	}
	public void setSchdulChargerNm(String schdulChargerNm) {
		this.schdulChargerNm = schdulChargerNm;
	}
	public String getSchdulChargerTelNo() {
		return schdulChargerTelNo;
	}
	public void setSchdulChargerTelNo(String schdulChargerTelNo) {
		this.schdulChargerTelNo = schdulChargerTelNo;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getPageTy() {
		return pageTy;
	}
	public void setPageTy(String pageTy) {
		this.pageTy = pageTy;
	}
	public boolean isCheckYn() {
		return checkYn;
	}
	public void setCheckYn(boolean checkYn) {
		this.checkYn = checkYn;
	}
	public String getSchdulFreq() {
		return schdulFreq;
	}
	public void setSchdulFreq(String schdulFreq) {
		this.schdulFreq = schdulFreq;
	}
	public String getSchdulInterval() {
		return schdulInterval;
	}
	public void setSchdulInterval(String schdulInterval) {
		this.schdulInterval = schdulInterval;
	}
	public String getSchdulSmsId() {
		return schdulSmsId;
	}
	public void setSchdulSmsId(String schdulSmsId) {
		this.schdulSmsId = schdulSmsId;
	}
	public String getUpdateAuth() {
		return updateAuth;
	}
	public void setUpdateAuth(String updateAuth) {
		this.updateAuth = updateAuth;
	}
	public String getSendTrpr() {
		return sendTrpr;
	}
	public void setSendTrpr(String sendTrpr) {
		this.sendTrpr = sendTrpr;
	}
	public String getSchdulFreqSn() {
		return schdulFreqSn;
	}
	public void setSchdulFreqSn(String schdulFreqSn) {
		this.schdulFreqSn = schdulFreqSn;
	}
	public String getSchdulFreqBgnDt() {
		return schdulFreqBgnDt;
	}
	public void setSchdulFreqBgnDt(String schdulFreqBgnDt) {
		this.schdulFreqBgnDt = schdulFreqBgnDt;
	}
	
}
