package egovframework.let.skd.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class  ScheduleSmsVO implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/** SMS ID*/
	private String smsId ;
	/** 유저코드*/
    private String userCode ="kangwonland6" ;
    /** 발신자*/
    private String reqName = "강원랜드" ;
    /** 발신연락처*/
    private String reqPhone = "15887789" ;
    /** 수신자*/
    private String callName ;
    /** 수신자 연락처*/
    private String callPhone ;
    /** 제목*/
    private String subject ;
    /** 메시지*/
    private String msg ;
    /** 전송일시*/
    private String reqTime ;
    /** 전송방식*/
    private String result = "R" ;
    /** 발송구분*/
    private String kind ="S" ;
    /** 발송모드*/
    private String sendProgMod ;
    /** 수신자ID*/
    private String recvId ;
    /** 임시키값*/
    private String fkContent ;
    /** 등록자*/
    private String frstRegisterId ;
    /** 수정자*/
    private String lastUpdusrId   ;
    /** 발송구분*/
    private String sendSe ;
    
    
	public String getSmsId() {
		return smsId;
	}
	public void setSmsId(String smsId) {
		this.smsId = smsId;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getReqName() {
		return reqName;
	}
	public void setReqName(String reqName) {
		this.reqName = reqName;
	}
	public String getReqPhone() {
		return reqPhone;
	}
	public void setReqPhone(String reqPhone) {
		this.reqPhone = reqPhone;
	}
	public String getCallName() {
		return callName;
	}
	public void setCallName(String callName) {
		this.callName = callName;
	}
	public String getCallPhone() {
		return callPhone;
	}
	public void setCallPhone(String callPhone) {
		this.callPhone = callPhone;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getReqTime() {
		return reqTime;
	}
	public void setReqTime(String reqTime) {
		this.reqTime = reqTime;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getSendProgMod() {
		return sendProgMod;
	}
	public void setSendProgMod(String sendProgMod) {
		this.sendProgMod = sendProgMod;
	}
	public String getRecvId() {
		return recvId;
	}
	public void setRecvId(String recvId) {
		this.recvId = recvId;
	}
	public String getFkContent() {
		return fkContent;
	}
	public void setFkContent(String fkContent) {
		this.fkContent = fkContent;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getSendSe() {
		return sendSe;
	}
	public void setSendSe(String sendSe) {
		this.sendSe = sendSe;
	}
    
}
