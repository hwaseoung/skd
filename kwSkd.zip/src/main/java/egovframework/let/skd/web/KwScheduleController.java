package egovframework.let.skd.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.egovframe.rte.fdl.cmmn.exception.EgovBizException;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.KwCmmUseService;
import egovframework.let.skd.service.KwScheduleService;
import egovframework.let.skd.service.Schedule;
import egovframework.let.skd.service.ScheduleDefaultVO;
import egovframework.let.sym.ccm.ccc.service.CmmnClCodeVO;
import egovframework.let.sym.ccm.ccc.service.KwCcmCmmnClCodeManageService;
import egovframework.let.utl.fcc.service.DateUtil;
import egovframework.let.utl.fcc.service.StringUtil;

@Controller
public class KwScheduleController {
	@Resource(name = "CmmnClCodeManageService")
    private KwCcmCmmnClCodeManageService cmmnClCodeManageService;

    
	/** KwScheduleService */
    @Resource(name = "KwScheduleService")
    private KwScheduleService kwScheduleService;
    
    /** cmmUseService */
	@Resource(name = "KwCmmUseService")
	private KwCmmUseService cmmUseService;

    /** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;
	
	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	@RequestMapping(value = "/skd/scheduleView.do")
	public String getMgtMainPage(HttpServletRequest request, @RequestParam Map<String, Object> commandMap, ModelMap model) throws IOException
	  {
		
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		String initDate =  DateUtil.getToday();
		String initView =  "dayGridMonth";
		if( commandMap.size() > 0 && !commandMap.get("initDate").toString().equals("")) {
			initDate =commandMap.get("initDate").toString();
		}
		
		if(commandMap.size() > 0 && !commandMap.get("initView").toString().equals("")) {
			initView = commandMap.get("initView").toString();
		}
		int holidayCnt = -1;
		//방화벽 해제 및 서비스키 발급 이후 사용가능
		holidayCnt = kwScheduleService.holidayCnt();//해당 년도 공휴일 존재여부	
		
		model.addAttribute("holidayCnt", holidayCnt);	//공휴일 건수
		model.addAttribute("initDate", initDate);		//날짜세팅
		model.addAttribute("initView", initView);		//뷰세팅
		
		
		if(user.getId().equals("admin")) {
			return "cmm/skd/KwScheduleView";
		}else {
			return "main/KwMainView";
		}
	}
	
	/**
	 * 일정정보 목록 조회한다.
	 * @throws EgovBizException 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/skd/schedule.do")
	@ResponseBody
	public ModelAndView scheduleList(@ModelAttribute("schdulForm") Schedule scheduleVO,
			@RequestParam Map<String, Object> commandMap,
			 ModelMap model) throws Exception  {
			
		List<Map<String, Object>> list = kwScheduleService.scheduleList(scheduleVO);
		JSONObject jsonObj = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		String timeStr =null;
		ModelAndView mav = new ModelAndView("jsonView");
		try {
			if(list.size() <= 0) {
				throw new RuntimeException("목록이 존재하지 않습니다.");
			}
			for(int i=0; i < list.size(); i++) {
				HashMap<String, Object> hash = new HashMap<String, Object>();
				
				hash.put("id", list.get(i).get("schdulId")); //ID
				hash.put("title", list.get(i).get("schdulSj")); //제목
				hash.put("schdulCn", list.get(i).get("schdulCn")); //내용
				if(list.get(i).get("allDay").equals("true")) {
					hash.put("endB",DateUtil.formatDate(DateUtil.addDay(list.get(i).get("schdulEndDt").toString(),-1),"-")); //종료일자
				}else {
					hash.put("endB", list.get(i).get("schdulEndDt")); //종료일자
					hash.put("duration", DateUtil.getTimeDiff(list.get(i).get("schdulBgnDt").toString(), list.get(i).get("schdulEndDt").toString())); //시작일시 종료일시 시간차이
				}
				hash.put("allday", list.get(i).get("allDay")); //ALLDAY
				hash.put("backgroundColor", list.get(i).get("schdulClr")); //배경컬러
				hash.put("borderColor", list.get(i).get("schdulClr")); //컬러
				hash.put("schdulChargerNm", list.get(i).get("schdulChargerNm")); //담당자
				hash.put("schdulAdminNm", list.get(i).get("schdulAdminNm")); //관리자
				hash.put("clCodeNm", list.get(i).get("clCodeNm")); //작업구분
				hash.put("clCodeIdNm", list.get(i).get("clCodeIdNm")); //작업상세구분
				hash.put("schdulFreq", list.get(i).get("schdulFreq")); //일정주기 표시용
				hash.put("schdulInterval", list.get(i).get("schdulInterval")); //일정간격 표시용
				hash.put("schdulFreqSn", list.get(i).get("schdulFreqSn")); //일정주기일련번호
			    if(!list.get(i).get("schdulFreqBgnDt").equals("")) {
					hash.put("start", list.get(i).get("schdulFreqBgnDt")); //그룹시작일자
					hash.put("startB", list.get(i).get("schdulFreqBgnDt")); //시작일자
					if(list.get(i).get("allDay").equals("false")) {
						timeStr = list.get(i).get("schdulEndDt").toString();
						hash.put("end", StringUtil.cutString(list.get(i).get("schdulFreqBgnDt").toString(), 10)+" "+timeStr.substring(11, 16)); //종료일자
					}
				}else {
					hash.put("start", list.get(i).get("schdulBgnDt")); //시작일자
					hash.put("startB", list.get(i).get("schdulBgnDt")); //시작일자
					hash.put("end", list.get(i).get("schdulEndDt")); //종료일자
				}
			    //시작일자가 오늘보다 작으면 이동제한
			    if(DateUtil.getDaysDiff(DateUtil.addDay(StringUtil.cutString(hash.get("start").toString(),10),0), DateUtil.getToday()) > 0) {
			    	hash.put("editable", false); //이동제한
			    }
			   
				jsonObj = new JSONObject(hash);
				jsonArr.add(jsonObj);
			}
			
		} catch (RuntimeException e) {
			System.out.println(e.getMessage());
		} finally {
			mav.addObject("resultList", jsonArr);		//목록리스트
			mav.addObject("initDate", scheduleVO.getSchdulBgnDt());
		}
		return mav;
	}
	/**
	 * 일정정보 등록화면 호출한다.
	 */
	@RequestMapping(value = "/skd/scheduleInsertPop.do")
	public String scheduleInsertPop(@ModelAttribute("schedule") Schedule schedule,
			@RequestParam Map<String, Object> commandMap, ModelMap model) throws Exception
	  {
    	
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	//공통코드 활용
    	ComDefaultCodeVO vo = new ComDefaultCodeVO();
    	//작업그룹
    	if(!loginVO.getUserSe().equals("ADMIN")) {
    		vo.setTableNm("ALL");
    	}
    	
    	vo.setCodeId(loginVO.getClCode());
		List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
    	model.addAttribute("cmmnClCode", cmmnClCode);
    	
		//색상
		vo.setCodeId("CM0003");
		model.addAttribute("schdulClrCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//알람구분
		vo.setCodeId("CM0002");
		model.addAttribute("sendSeCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//일정주기
		vo.setCodeId("CM0004");
		model.addAttribute("schdulFreqCode", cmmUseService.selectCmmCodeDetail(vo));
		
		String endDt = commandMap.get("endDt").toString();
		if(commandMap.get("allDay").toString().equals("true")){
			endDt = DateUtil.addDay(endDt, -1);
			endDt = DateUtil.formatDate(endDt, "-");
		}else{
			 endDt = commandMap.get("endDt").toString();
		}
		
		model.addAttribute("startDt",commandMap.get("startDt"));
		model.addAttribute("endDt",endDt);
		model.addAttribute("allDay",commandMap.get("allDay").toString());
    	
    	return "cmm/skd/KwScheduleInsert";
	}
	
	@RequestMapping("/skd/scheduleInsert.do")
	@ResponseBody
	public ModelAndView scheduleInsert(@ModelAttribute("schedule") Schedule schedule,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception{
		
		ModelAndView mav = new ModelAndView("jsonView");
		
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		schedule.setFrstRegisterId(loginVO.getId());
		try {
			if(schedule.getSchdulBgnDt().equals("") || schedule.getSchdulEndDt().equals("")) {
				throw new NullPointerException("null이 존재 합니다.");
			}
			
			if(schedule.getAllDay().equals("true")){
	    		schedule.setSchdulBgnDt(StringUtil.cutString(schedule.getSchdulBgnDt(), 10));
	    		schedule.setSchdulEndDt(StringUtil.cutString(schedule.getSchdulEndDt(), 10));
	    	}
			
			kwScheduleService.scheduleInsert(schedule);
			
			mav.addObject("result", "OK");
			
		} catch (NullPointerException e) {
			
			System.out.println(e.getMessage());
			mav.addObject("result", "FAIL");
		}
		return mav;
	}
	
	/**
	 * 일정정보 수정화면 호출한다.
	 */
	@RequestMapping("/skd/scheduleUpdtPop.do")
	public String scheduleUpdtPop(@RequestParam Map<String, Object> commandMap,
			Model model) throws Exception {
    	
    	Schedule schedule = new Schedule();
    	schedule = kwScheduleService.selectSchdule(commandMap.get("schduleId").toString());
    	model.addAttribute("schedule", schedule);
		
    	LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
    	
    	//유저이면서 일정작업구분이 전체인 경우 N
    	if(loginVO.getUserSe().equals("USER") && schedule.getClCode().equals("ALL")) {
    		schedule.setUpdateAuth("N");
    		
    	}// 세션 서브작업코드가 존재하면서 세션서브 작업구분코드와 일정 서브작업구분코드 같지 않는 경우 N
    	else if(!loginVO.getClCodeId().equals("") && !schedule.getClCodeId().equals(loginVO.getClCodeId()) ) {
    		schedule.setUpdateAuth("N");
    	}else {
    		schedule.setUpdateAuth("Y");
    	}
    	
    	
    	//공통코드 활용
    	ComDefaultCodeVO vo = new ComDefaultCodeVO();
    	//작업그룹
    	if(schedule.getClCode() !=null) {
    		vo.setCodeId(schedule.getClCode());
    	}
		List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
    	model.addAttribute("cmmnClCode", cmmnClCode);

    	//작업상세그룹
    	model.addAttribute("cmmnClCodeDetail", cmmUseService.selectCmmClCodeDetail(vo));
        
        ///색상
		vo.setCodeId("CM0003");
		model.addAttribute("schdulClrCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//알람구분
		vo.setCodeId("CM0002");
		model.addAttribute("sendSeCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//일정주기
		vo.setCodeId("CM0004");
		model.addAttribute("schdulFreqCode", cmmUseService.selectCmmCodeDetail(vo));
    	
		return "cmm/skd/KwScheduleUpdt";
	}
	
	/**
	 * 일정정보 수정화면 호출한다.
	 */
	@RequestMapping("/skd/scheduleDropSize.do")
	public String scheduleDropSize(@RequestParam Map<String, Object> commandMap,
			Model model) throws Exception{
    	
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	Schedule schedule = new Schedule();
    	schedule = kwScheduleService.selectSchdule(commandMap.get("schduleId").toString());
    	if(!commandMap.get("schdulFreqSn").toString().equals("")) {
    		schedule.setPageTy("DrSi");
    	}
    	schedule.setAllDay(commandMap.get("allDay").toString());
    	schedule.setSchdulBgnDt(commandMap.get("startDt").toString());
    	schedule.setSchdulFreqSn(commandMap.get("schdulFreqSn").toString());
    	String endDt = commandMap.get("endDt").toString();
    	String newDate = commandMap.get("startDt").toString();
    	String newDt = newDate.substring(0, 10);
    	
    	//유저이면서 일정작업구분이 전체인 경우 N
    	if(loginVO.getUserSe().equals("USER") && schedule.getClCode().equals("ALL")) {
    		schedule.setUpdateAuth("N");
    		
    	}else if(!loginVO.getClCodeId().equals("") && !schedule.getClCodeId().equals(loginVO.getClCodeId()) ) {
    		schedule.setUpdateAuth("N");
    	}else {
    		schedule.setUpdateAuth("Y");
    	}
    	
		if(commandMap.get("allDay").toString().equals("true")){
			if(endDt.equals("")) {
				endDt = commandMap.get("startDt").toString();
				
			}else {
				endDt = DateUtil.addDay(endDt, -1);
				endDt = DateUtil.formatDate(endDt, "-");
			}
			
		}else {
			if(endDt.equals("")) {
				String newTm = newDate.substring(11, newDate.length());
				endDt = DateUtil.addYMDtoDayTime(newDt,newTm,0,0,0,0,30,"yyyy-MM-dd HH:mm");
			}
		}
		
		schedule.setSchdulEndDt(endDt);
    	model.addAttribute("schedule", schedule);
		
    	//공통코드 활용
    	ComDefaultCodeVO vo = new ComDefaultCodeVO();
    	
    	if(schedule.getClCode() !=null) {
    		vo.setCodeId(schedule.getClCode());
    	}
		List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
    	model.addAttribute("cmmnClCode", cmmnClCode);
    	//작업상세그룹
    	model.addAttribute("cmmnClCodeDetail", cmmUseService.selectCmmClCodeDetail(vo));
        
        ///색상
		vo.setCodeId("CM0003");
		model.addAttribute("schdulClrCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//알람구분
		vo.setCodeId("CM0002");
		model.addAttribute("sendSeCode", cmmUseService.selectCmmCodeDetail(vo));
		
		//일정주기
		vo.setCodeId("CM0004");
		model.addAttribute("schdulFreqCode", cmmUseService.selectCmmCodeDetail(vo));		
    	
		return "cmm/skd/KwScheduleUpdt";
	}
	
	
	@RequestMapping("/skd/scheduleUpdt.do")
	@ResponseBody
	public ModelAndView scheduleUpdt(@ModelAttribute("schedule") Schedule schedule,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {
		
		ModelAndView mav = new ModelAndView("jsonView");
		
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		schedule.setLastUpdusrId(loginVO.getId());
		schedule.setFrstRegisterId(loginVO.getId());
		
		if(schedule.getAllDay().equals("true")){
    		schedule.setSchdulBgnDt(StringUtil.cutString(schedule.getSchdulBgnDt(), 10));
    		schedule.setSchdulEndDt(StringUtil.cutString(schedule.getSchdulEndDt(), 10));
    	}
		
		//일정 수정시 히스토리 정보를 등록한다.
		kwScheduleService.insertSchdulHistory(schedule);
		
		kwScheduleService.scheduleUpdate(schedule);
		
		mav.addObject("result", "OK");
		
		return mav;
	}
	
	
	@RequestMapping("/skd/scheduleRemove.do")
	@ResponseBody
	public ModelAndView scheduleRemove(@ModelAttribute("schedule") Schedule schedule,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {
		
		ModelAndView mav = new ModelAndView("jsonView");
		
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		schedule.setLastUpdusrId(loginVO.getId());
		
		kwScheduleService.scheduleRemove(schedule);
		
		mav.addObject("result", "OK");
		
		return mav;
	}

	
	@RequestMapping( "/skd/scheduleList.do")
	public String scheduleList(@ModelAttribute("scheduleDefaultVO") ScheduleDefaultVO scheduleDefaultVO, ModelMap model, HttpServletRequest request) throws Exception {

    	
		/** EgovPropertyService */
    	scheduleDefaultVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	scheduleDefaultVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(scheduleDefaultVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(scheduleDefaultVO.getPageUnit());
		paginationInfo.setPageSize(scheduleDefaultVO.getPageSize());

		scheduleDefaultVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		scheduleDefaultVO.setLastIndex(paginationInfo.getLastRecordIndex());
		scheduleDefaultVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> scheduleList = kwScheduleService.scheduleList(scheduleDefaultVO);
		
		model.addAttribute("resultList",scheduleList);

		int totCnt = kwScheduleService.scheduleListTotCnt(scheduleDefaultVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		//분류코드 조회
		CmmnClCodeVO searchVO;
		searchVO = new CmmnClCodeVO();
		searchVO.setRecordCountPerPage(999999);
		searchVO.setFirstIndex(0);
		searchVO.setSearchCondition("CodeList");
        model.addAttribute("cmmnClCode", cmmnClCodeManageService.selectCmmnClCodeList(searchVO));

		return "cmm/skd/KwScheduleList";
	}
	
	/**
	 * 일정정보 수정화면 호출한다.
	 */
	@RequestMapping("/skd/updtSchedule.do")
	public String updtSchedule(@ModelAttribute("schedule") Schedule schedule, @RequestParam Map<String, Object> commandMap,
			Model model) throws Exception{
		
		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		if (sCmd.equals("")) {
	    	schedule = kwScheduleService.selectSchdule(commandMap.get("schduleId").toString());
	    	model.addAttribute("schedule", schedule);
			
	    	//유저이면서 일정작업구분이 전체인 경우 N
	    	if(loginVO.getUserSe().equals("USER") && schedule.getClCode().equals("ALL")) {
	    		schedule.setUpdateAuth("N");
	    		
	    	}else if(!loginVO.getClCodeId().equals("") && !schedule.getClCodeId().equals(loginVO.getClCodeId()) ) {
	    		schedule.setUpdateAuth("N");
	    	}else {
	    		schedule.setUpdateAuth("Y");
	    	}
	    	
	    	//공통코드 활용
	    	ComDefaultCodeVO vo = new ComDefaultCodeVO();
	    	//작업그룹
	    	if(!loginVO.getUserSe().equals("ADMIN")) {
	    		vo.setTableNm("ALL");
	    	}
	    	if(schedule.getClCode() !=null) {
	    		vo.setCodeId(schedule.getClCode());
	    	}
			List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
	    	model.addAttribute("cmmnClCode", cmmnClCode);
	    	//작업상세그룹
	    	model.addAttribute("cmmnClCodeDetail", cmmUseService.selectCmmClCodeDetail(vo));
	        
	        ///색상
			vo.setCodeId("CM0003");
			model.addAttribute("schdulClrCode", cmmUseService.selectCmmCodeDetail(vo));
			
			//알람구분
			vo.setCodeId("CM0002");
			model.addAttribute("sendSeCode", cmmUseService.selectCmmCodeDetail(vo));
			
			//일정주기
			vo.setCodeId("CM0004");
			model.addAttribute("schdulFreqCode", cmmUseService.selectCmmCodeDetail(vo));
			
			return "cmm/skd/KwScheduleModify";
		}else {
			schedule.setLastUpdusrId(loginVO.getId());
			schedule.setFrstRegisterId(loginVO.getId());
			
			if(schedule.getAllDay().equals("true")){
	    		schedule.setSchdulBgnDt(StringUtil.cutString(schedule.getSchdulBgnDt(), 10));
	    		schedule.setSchdulEndDt(StringUtil.cutString(schedule.getSchdulEndDt(), 10));
	    	}
			
			//일정 수정시 히스토리 정보를 등록한다.
			kwScheduleService.insertSchdulHistory(schedule);
			
			kwScheduleService.scheduleUpdate(schedule);
			
			return "redirect:/skd/scheduleList.do";
		}
    	
	}

	/**
	 * 일정정보 등록화면 호출한다.
	 */
	@RequestMapping("/skd/scheduleRegist.do")
	public String scheduleRegist(@ModelAttribute("schedule") Schedule schedule, ModelMap model)
	  throws Exception{
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		if(schedule.getClCode() == null || schedule.getClCode().equals("")) {
			
	    	//공통코드 활용
	    	ComDefaultCodeVO vo = new ComDefaultCodeVO();
	    	//작업그룹
	    	if(!loginVO.getUserSe().equals("ADMIN")) {
	    		vo.setTableNm("ALL");
	    	}
	    	vo.setCodeId(loginVO.getClCode());
			List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
	    	model.addAttribute("cmmnClCode", cmmnClCode);
	
			//색상
			vo.setCodeId("CM0003");
			model.addAttribute("schdulClrCode", cmmUseService.selectCmmCodeDetail(vo));
			
			//알람구분
			vo.setCodeId("CM0002");
			model.addAttribute("sendSeCode", cmmUseService.selectCmmCodeDetail(vo));
			
			//일정주기
			vo.setCodeId("CM0004");
			model.addAttribute("schdulFreqCode", cmmUseService.selectCmmCodeDetail(vo));
		
			return "cmm/skd/KwScheduleRegist";
	    }else {
			
			schedule.setFrstRegisterId(loginVO.getId());
			
			if(schedule.getAllDay().equals("true")){
	    		schedule.setSchdulBgnDt(StringUtil.cutString(schedule.getSchdulBgnDt(), 10));
	    		schedule.setSchdulEndDt(StringUtil.cutString(schedule.getSchdulEndDt(), 10));
	    	}
			
			kwScheduleService.scheduleInsert(schedule);
			return "redirect:/skd/scheduleList.do";
	    }
	}

	/**
	 * 일정정보삭제 후 목록화면 호출
	 */
	@RequestMapping("/skd/scheduleDelete.do")
	public String deleteUser(@ModelAttribute("schedule") Schedule schedule,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {


	   LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		schedule.setLastUpdusrId(loginVO.getId());
		
		kwScheduleService.scheduleRemove(schedule);
		
		return "redirect:/skd/scheduleList.do";
	}
	
	/**
	 * 알림일시 목록 조회한다.
	 */
	@RequestMapping("/skd/selectSmsList.do")
	public String selectSmsList(@RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") ScheduleDefaultVO searchVO, ModelMap model) throws Exception {

		// 내역 조회
		searchVO.setPageUnit(4);
		searchVO.setPageSize(4);
        searchVO.setSearchKeyword(commandMap.get("schduleId").toString());
		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> list = kwScheduleService.selectSmsList(searchVO);
		model.addAttribute("listSms", list);

		int totCnt = kwScheduleService.selectSmsListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "cmm/skd/KwSmsInfoList";

	}
	
	/**
	 * 선택 팝업.
	 */
	@RequestMapping("/skd/selectPop.do")
	public String selectPop(@RequestParam Map<String, Object> commandMap, ModelMap model){
		
		model.addAttribute("updateYn", commandMap.get("updateYn").toString());
		
	return "cmm/skd/KwScheduleCnfirm";
	}
	
	/**
	 * 알림주기 목록 조회한다.
	 */
	@RequestMapping("/skd/selectFreqList.do")
	public String selectFreqList(@RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") ScheduleDefaultVO searchVO, ModelMap model) throws Exception {

		// 내역 조회
		searchVO.setPageUnit(4);
		searchVO.setPageSize(4);
        searchVO.setSearchKeyword(commandMap.get("schduleId").toString());
		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> list = kwScheduleService.selectFreqList(searchVO);
		model.addAttribute("listFreq", list);

		int totCnt = kwScheduleService.selectFreqListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "cmm/skd/KwFreqInfoList";

	}
	
	/**
	 * 공휴일 정보 조회한다.
	 * @throws EgovBizException 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/skd/holidayList.do")
	@ResponseBody
	public ModelAndView holidayList(@ModelAttribute("schdulForm") Schedule scheduleVO,
			@RequestParam Map<String, Object> commandMap,
			 ModelMap model) throws Exception  {
		List<Map<String, Object>> list = kwScheduleService.holidayList(scheduleVO);	
		JSONObject jsonObj = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		ModelAndView mav = new ModelAndView("jsonView");
		try {
			if(list.size() <= 0) {
				throw new RuntimeException("목록이 존재하지 않습니다.");
			}
			for(int i=0; i < list.size(); i++) {
				HashMap<String, Object> hash = new HashMap<String, Object>();
				
				hash.put("title", list.get(i).get("holidayNm")); //제목
				if(list.get(i).get("isHoliday").equals("Y")) {
					hash.put("schdulCn", "공휴일 공공기관 휴무"); //내용
				}else {
					hash.put("schdulCn", list.get(i).get("holidayNm")); //내용
				}
				hash.put("allday", "true"); //ALLDAY
				hash.put("backgroundColor", "#BE2E22"); //배경컬러
				hash.put("borderColor", "#BE2E22"); //컬러D25565
				hash.put("start", DateUtil.formatDate(list.get(i).get("holidayDt").toString(),"-")); //시작일자
				hash.put("startB", DateUtil.formatDate(list.get(i).get("holidayDt").toString(),"-")); //시작일자
				hash.put("end", DateUtil.formatDate(list.get(i).get("holidayDt").toString(),"-")); //종료일자
				hash.put("endB", DateUtil.formatDate(list.get(i).get("holidayDt").toString(),"-")); //종료일자
				hash.put("editable", false); //휴무는 이동제한
				//hash.put("color", "#ff9f89"); //컬러
				jsonObj = new JSONObject(hash);
				jsonArr.add(jsonObj);
			}
			
		} catch (RuntimeException e) {
			System.out.println(e.getMessage());
		} finally {
			mav.addObject("holidayList", jsonArr);	
		}
		return mav;
	}
	
	/**
	 * 공휴일 저장
	 */
	@RequestMapping("/skd/holidayInert.do")
	public ModelAndView holidayInert(	@RequestParam Map<String, Object> commandMap, ModelMap model) throws Exception {
		ModelAndView mav = new ModelAndView("jsonView");
		
		kwScheduleService.getHolidayService();
		
		mav.addObject("result", "OK");
				
		return mav;
	}
}