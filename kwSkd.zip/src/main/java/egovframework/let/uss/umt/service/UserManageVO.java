package egovframework.let.uss.umt.service;

public class UserManageVO extends UserDefaultVO{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

    /**
	 * 가입일
	 */
	private String sbscrbDe;
	/**
	 * 사용자 유형
	 */
	private String userSe;
	/**
	 * 사용자 유형명
	 */
	private String userSeNm;
	/**
	 * 이메일주소
	 */
	private String userEmail;
	/**
	 * 사용자 ID
	 */
	private String userId;
	/**
	 * 사용자 명
	 */
	private String userNm;
	/**
	 * 작업그룹 ID
	 */
	private String clCode;
	/**
	 * 작업그룹 ID명
	 */
	private String clCodeNm;
	/**
	 * 작업세부그룹
	 */
	private String clCodeId;
	/**
	 * 작업세부그룹명
	 */
	private String clCodeIdNm;
	/**
	 * 핸드폰번호
	 */
	private String moblphonNo;
	/**
	 * 비밀번호
	 */
	private String password;
	/**
	 * 등록자ID
	 */
	private String frstRegisterId;
	/**
	 * 수정자ID
	 */
	private String lastUpdusrId;
	/**
	 * 최근접속일자
	 */
	private String lastLogDt;
	/**
	 * 잠금횟수
	 */
	private String lockCnt;
	public String getSbscrbDe() {
		return sbscrbDe;
	}
	public void setSbscrbDe(String sbscrbDe) {
		this.sbscrbDe = sbscrbDe;
	}
	public String getUserSe() {
		return userSe;
	}
	public void setUserSe(String userSe) {
		this.userSe = userSe;
	}
	public String getUserSeNm() {
		return userSeNm;
	}
	public void setUserSeNm(String userSeNm) {
		this.userSeNm = userSeNm;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getClCode() {
		return clCode;
	}
	public void setClCode(String clCode) {
		this.clCode = clCode;
	}
	public String getClCodeNm() {
		return clCodeNm;
	}
	public void setClCodeNm(String clCodeNm) {
		this.clCodeNm = clCodeNm;
	}
	public String getClCodeId() {
		return clCodeId;
	}
	public void setClCodeId(String clCodeId) {
		this.clCodeId = clCodeId;
	}
	public String getClCodeIdNm() {
		return clCodeIdNm;
	}
	public void setClCodeIdNm(String clCodeIdNm) {
		this.clCodeIdNm = clCodeIdNm;
	}
	public String getMoblphonNo() {
		return moblphonNo;
	}
	public void setMoblphonNo(String moblphonNo) {
		this.moblphonNo = moblphonNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getLastLogDt() {
		return lastLogDt;
	}
	public void setLastLogDt(String lastLogDt) {
		this.lastLogDt = lastLogDt;
	}
	public String getLockCnt() {
		return lockCnt;
	}
	public void setLockCnt(String lockCnt) {
		this.lockCnt = lockCnt;
	}
	
}