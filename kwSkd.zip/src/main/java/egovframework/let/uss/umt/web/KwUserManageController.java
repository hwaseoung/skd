package egovframework.let.uss.umt.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.KwCmmUseService;
import egovframework.let.uss.umt.service.KwUserManageService;
import egovframework.let.uss.umt.service.UserDefaultVO;
import egovframework.let.uss.umt.service.UserManageVO;
import egovframework.let.utl.sim.service.EgovFileScrty;


@Controller
public class KwUserManageController {

	/** userManageService */
	@Resource(name = "userManageService")
	private KwUserManageService userManageService;

	/** cmmUseService */
	@Resource(name = "KwCmmUseService")
	private KwCmmUseService cmmUseService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** DefaultBeanValidator beanValidator */
	@Autowired
	private DefaultBeanValidator beanValidator;

	/**
	 * 사용자목록을 조회한다. (pageing)
	 * @param userSearchVO 검색조건정보
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovUserManage
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/umt/user/KwUserManage.do")
	public String selectUserList(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, ModelMap model, HttpServletRequest request) throws Exception {

		/** EgovPropertyService */
		userSearchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		userSearchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(userSearchVO.getPageUnit());
		paginationInfo.setPageSize(userSearchVO.getPageSize());

		userSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		model.addAttribute("resultList", userManageService.selectUserList(userSearchVO));

		int totCnt = userManageService.selectUserListTotCnt(userSearchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		//사용자상태코드를 코드정보로부터 조회
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		//작업그룹
    	model.addAttribute("cmmnClCode", cmmUseService.selectCmmClCode(vo));

    	//사용자 유형
		vo.setCodeId("CM0001");
		model.addAttribute("userSeCode", cmmUseService.selectCmmCodeDetail(vo));

		return "cmm/uss/umt/KwUserManage";
	}

	/**
	 * 사용자등록화면으로 이동한다.
	 * @param userSearchVO 검색조건정보
	 * @param userManageVO 사용자초기화정보
	 * @param model 화면모델
	 * @return cmm/uss/umt/KwUserInsert
	 * @throws Exception
	 */
	@RequestMapping("/uss/umt/user/KwUserInsertView.do")
	public String insertUserView(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, @ModelAttribute("userManageVO") UserManageVO userManageVO, Model model)
			throws Exception {

		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//작업그룹
		List<?> cmmnClCode = cmmUseService.selectCmmClCode(vo);
    	model.addAttribute("cmmnClCode", cmmnClCode);

		//사용자 유형
		vo.setCodeId("CM0001");
		model.addAttribute("userSeCode", cmmUseService.selectCmmCodeDetail(vo));

		return "cmm/uss/umt/KwUserInsert";
	}

	/**
	 * 사용자등록처리후 목록화면으로 이동한다.
	 * @param userManageVO 사용자등록정보
	 * @param bindingResult 입력값검증용 bindingResult
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/KwUserManage.do
	 * @throws Exception
	 */
	@RequestMapping("/uss/umt/user/KwUserInsert.do")
	public String insertUser(@ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult,
						Model model, RedirectAttributes rttr) throws Exception {

    	LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	userManageVO.setFrstRegisterId(loginVO.getId());
		
		beanValidator.validate(userManageVO, bindingResult);
		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			//작업그룹
	    	model.addAttribute("cmmnClCode", cmmUseService.selectCmmClCode(vo));

	    	//사용자 유형
			vo.setCodeId("CM0001");
			model.addAttribute("userSeCode", cmmUseService.selectCmmCodeDetail(vo));

			return "cmm/uss/umt/KwUserInsert";
		} else {
			userManageService.insertUser(userManageVO);
			//Exception 없이 진행시 등록성공메시지
			//model.addAttribute("resultMsg", "success.common.insert");
			rttr.addFlashAttribute("resultMsg", "success.common.insert");
		}
		return "redirect:/uss/umt/user/KwUserManage.do";
	}

	/**
	 * 사용자정보 수정을 위해 사용자정보를 상세조회한다.
	 * @param userId 상세조회대상 사용자아이디
	 * @param userSearchVO 검색조건
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovUserSelectUpdt
	 * @throws Exception
	 */
	@RequestMapping("/uss/umt/user/KwUserSelectUpdtView.do")
	public String updateUserView(@RequestParam("selectedId") String userId, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
						Model model, @RequestParam Map<String, Object> commandMap) throws Exception {

    	String topView = (String) commandMap.get("topView");
    	
    	UserManageVO userManageVO = new UserManageVO();
		userManageVO = userManageService.selectUser(userId);

		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//작업그룹
    	model.addAttribute("cmmnClCode", cmmUseService.selectCmmClCode(vo));
    	
    	if(userManageVO.getClCode() !=null) {
    		vo.setCodeId(userManageVO.getClCode());
    	}
    	//작업상세그룹
    	model.addAttribute("cmmnClCodeDetail", cmmUseService.selectCmmClCodeDetail(vo));

    	//사용자 유형
		vo.setCodeId("CM0001");
		model.addAttribute("userSeCode", cmmUseService.selectCmmCodeDetail(vo));

		
		model.addAttribute("userSearchVO", userSearchVO);
		model.addAttribute("userManageUpdtVO", userManageVO);
		
		if(topView != null && topView.equals("Top")) {
			return "cmm/uss/umt/KwUserSelectUpdtPop";
		}else {
			return "cmm/uss/umt/KwUserSelectUpdt";
		}
		
	}

	/**
	 * 사용자정보 수정후 목록조회 화면으로 이동한다.
	 * @param userManageVO 사용자수정정보
	 * @param bindingResult 입력값검증용 bindingResult
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/KwUserManage.do
	 * @throws Exception
	 */
	@RequestMapping("/uss/umt/user/KwUserSelectUpdt.do")
	public String updateUser(@ModelAttribute("userManageUpdtVO") UserManageVO userManageVO, Model model, RedirectAttributes rttr) throws Exception {

    	LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	userManageVO.setLastUpdusrId(loginVO.getId());
    	
		//업무사용자 수정시 히스토리 정보를 등록한다.
		//userManageService.insertUserHistory(userManageVO);
		userManageService.updateUser(userManageVO);
		//Exception 없이 진행시 수정성공메시지
		//model.addAttribute("resultMsg", "success.common.update");
		rttr.addFlashAttribute("resultMsg", "success.common.update");
		return "redirect:/uss/umt/user/KwUserManage.do";
	}
	
	/**
	 * 사용자정보 수정후 일정캘린더 화면으로 이동한다.
	 * @param userManageVO 사용자수정정보
	 * @param model 화면모델
	 * @throws Exception
	 */
	@RequestMapping(value="/uss/umt/user/KwUserSelectUpdtPop.do")
	@ResponseBody
	public ModelAndView updateUserPop(@ModelAttribute("userManageUpdtVO") UserManageVO userManageVO,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {
		
		ModelAndView mav = new ModelAndView("jsonView");
		
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		userManageVO.setFrstRegisterId(loginVO.getId());
		
		
		userManageService.updateUser(userManageVO);
		
		mav.addObject("result", "OK");
		
		return mav;
	}

	/**
	 * 사용자정보삭제후 목록조회 화면으로 이동한다.
	 * @param checkedIdForDel 삭제대상아이디 정보
	 * @param userSearchVO 검색조건
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/KwUserManage.do
	 * @throws Exception
	 */
	@RequestMapping("/uss/umt/user/KwUserDelete.do")
	public String deleteUser(@RequestParam("checkedIdForDel") String checkedIdForDel, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
							Model model, RedirectAttributes rttr) throws Exception {

    	LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		userManageService.deleteUser(checkedIdForDel, loginVO.getId());
		//Exception 없이 진행시 등록성공메시지
		//model.addAttribute("resultMsg", "success.common.delete");
		rttr.addFlashAttribute("resultMsg", "success.common.delete");
		return "redirect:/uss/umt/user/KwUserManage.do";
	}

	/**
	 * 입력한 사용자아이디의 중복확인화면 이동
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovIdDplctCnfirm
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/umt/cmm/KwIdDplctCnfirmView.do")
	public String checkIdDplct(ModelMap model) throws Exception {

		model.addAttribute("checkId", "");
		model.addAttribute("usedCnt", "-1");
		return "cmm/uss/umt/KwIdDplctCnfirm";
	}

	/**
	 * 입력한 사용자아이디의 중복여부를 체크하여 사용가능여부를 확인
	 * @param commandMap 파라메터전달용 commandMap
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovIdDplctCnfirm
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/umt/cmm/KwIdDplctCnfirm.do")
	public String checkIdDplct(@RequestParam Map<String, Object> commandMap, ModelMap model) throws Exception {

		String checkId = (String) commandMap.get("checkId");
		checkId = new String(checkId.getBytes("ISO-8859-1"), "UTF-8");

		if (checkId == null || checkId.equals(""))
			return "forward:/uss/umt/KwIdDplctCnfirmView.do";

		int usedCnt = userManageService.checkIdDplct(checkId);
		model.addAttribute("usedCnt", usedCnt);
		model.addAttribute("checkId", checkId);

		return "cmm/uss/umt/KwIdDplctCnfirm";
	}

	/**
	 * 업무사용자 암호 수정처리 후 화면 이동
	 * @param model 화면모델
	 * @param commandMap 파라메터전달용 commandMap
	 * @param userSearchVO 검색조 건
	 * @param userManageVO 사용자수정정보(비밀번호)
	 * @return cmm/uss/umt/EgovUserPasswordUpdt
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/umt/user/KwUserPasswordUpdt.do")
	public String updatePassword(ModelMap model, @RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
			@ModelAttribute("userManageVO") UserManageVO userManageVO) throws Exception {

		String newPassword = (String) commandMap.get("newPassword");
		String userId = (String) commandMap.get("userId");

		UserManageVO resultVO = new UserManageVO();
		userManageVO.setPassword(newPassword);
		userManageVO.setUserId(userId);

		String resultMsg = "";
		resultVO = userManageService.selectPassword(userManageVO);

		if (resultVO != null) {
			userManageVO.setPassword(EgovFileScrty.encryptPassword(newPassword, resultVO.getUserId()));
			userManageService.updatePassword(userManageVO);
			model.addAttribute("userManageVO", userManageVO);
			resultMsg = "success.common.update";
		} else {
			model.addAttribute("userManageVO", userManageVO);
		}
		model.addAttribute("userSearchVO", userSearchVO);
		model.addAttribute("resultMsg", resultMsg);

		return "cmm/uss/umt/KwUserPasswordUpdt";
	}

	/**
	 * 업무사용자 암호 수정  화면 이동
	 * @param model 화면모델
	 * @param commandMap 파라메터전달용 commandMap
	 * @param userSearchVO 검색조건
	 * @param userManageVO 사용자수정정보(비밀번호)
	 * @return cmm/uss/umt/EgovUserPasswordUpdt
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/umt/user/KwUserPasswordUpdtView.do")
	public String updatePasswordView(ModelMap model, @RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
			@ModelAttribute("userManageVO") UserManageVO userManageVO) throws Exception {

		model.addAttribute("userManageVO", userManageVO);
		model.addAttribute("userSearchVO", userSearchVO);
		return "cmm/uss/umt/KwUserPasswordUpdt";
	}

}
