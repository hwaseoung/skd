package egovframework.let.batch;

import org.springframework.stereotype.Service;

@Service("sampleScheduling")
public class SampleScheduling{
	
	public void schedulerSample() throws Exception {
		
		System.out.println("스케쥴러 테스트");
		
		
	}
}