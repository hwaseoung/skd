package egovframework.let.batch.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.XML;

import egovframework.com.cmm.service.EgovProperties;

import org.json.JSONObject;

public class OpenApi {
	public static final String serviceKey = EgovProperties.getProperty("Globals.holiday.serviceKey");
	public static final String holiday = EgovProperties.getProperty("Globals.holiday.url");
	public static final String anniversary = EgovProperties.getProperty("Globals.anniversary.url");

    public JSONObject getHolidayApi(String solYear, String solMonth, String type) throws IOException {
        String rqUrl = holiday;
        if(!type.equals("holiday")) {
        	rqUrl = anniversary;
        }
    	StringBuilder urlBuilder = new StringBuilder(rqUrl); /*URL*/
        urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8") + "=" + serviceKey); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("solYear", "UTF-8") + "=" + URLEncoder.encode(solYear, "UTF-8")); /*연*/
        urlBuilder.append("&" + URLEncoder.encode("solMonth", "UTF-8") + "=" + URLEncoder.encode(solMonth, "UTF-8")); /*월*/
        URL url = new URL(urlBuilder.toString());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        conn.setConnectTimeout(10000); // 10초
        conn.setReadTimeout(10000); // 10초
        
        BufferedReader rd;
        if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder xmlSb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            xmlSb.append(line);
        }
        rd.close();
        conn.disconnect();
        JSONObject jsonSb = XML.toJSONObject(xmlSb.toString());
        return jsonSb;
    }
}