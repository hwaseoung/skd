package egovframework.let.sym.ccm.ccde.service;

import java.util.List;

import egovframework.com.cmm.service.CmmnDetailClCode;

public interface KwCcmCmmnDetailClCodeManageService {

	/**
	 * 분류상세코드를 삭제한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	void deleteCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception;

	/**
	 * 분류상세코드를 등록한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	void insertCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception;

	/**
	 * 분류상세코드 상세항목을 조회한다.
	 * @param cmmnDetailCode
	 * @return CmmnDetailCode(공통상세코드)
	 * @throws Exception
	 */
	CmmnDetailClCode selectCmmnDetailClCodeDetail(CmmnDetailClCode cmmnDetailClCode) throws Exception;

	/**
	 * 분류상세코드 목록을 조회한다.
	 * @param searchVO
	 * @return List(공통상세코드 목록)
	 * @throws Exception
	 */
	List<?> selectCmmnDetailClCodeList(CmmnDetailClCodeVO searchVO) throws Exception;

    /**
	 * 분류상세코드 총 갯수를 조회한다.
     * @param searchVO
     * @return int(공통상세코드 총 갯수)
     */
    int selectCmmnDetailClCodeListTotCnt(CmmnDetailClCodeVO searchVO) throws Exception;

	/**
	 * 분류상세코드를 수정한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	void updateCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception;

}
