package egovframework.let.sym.ccm.ccde.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.CmmnDetailClCode;
import egovframework.let.sym.ccm.ccde.service.CmmnDetailClCodeVO;

@Repository("CmmnDetailClCodeManageDAO")
public class CmmnDetailClCodeManageDAO extends EgovAbstractMapper {

	/**
	 * 분류상세코드를 삭제한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	public void deleteCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		delete("CmmnDetailClCodeManageDAO.deleteCmmnDetailClCode", cmmnDetailClCode);
	}


	/**
	 * 분류상세코드를 등록한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	public void insertCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
        insert("CmmnDetailClCodeManageDAO.insertCmmnDetailClCode", cmmnDetailClCode);
	}

	/**
	 * 분류상세코드 상세항목을 조회한다.
	 * @param cmmnDetailCode
	 * @return CmmnDetailCode(분류상세코드)
	 */
	public CmmnDetailClCode selectCmmnDetailClCodeDetail(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		return (CmmnDetailClCode) selectOne("CmmnDetailClCodeManageDAO.selectCmmnDetailClCodeDetail", cmmnDetailClCode);
	}


    /**
	 * 분류상세코드 목록을 조회한다.
     * @param searchVO
     * @return List(분류상세코드 목록)
     * @throws Exception
     */
	public List<?> selectCmmnDetailClCodeList(CmmnDetailClCodeVO searchVO) throws Exception {
        return list("CmmnDetailClCodeManageDAO.selectCmmnDetailClCodeList", searchVO);
    }

    /**
	 * 분류상세코드 총 갯수를 조회한다.
     * @param searchVO
     * @return int(분류상세코드 총 갯수)
     */
    public int selectCmmnDetailClCodeListTotCnt(CmmnDetailClCodeVO searchVO) throws Exception {
        return (Integer)selectOne("CmmnDetailClCodeManageDAO.selectCmmnDetailClCodeListTotCnt", searchVO);
    }

	/**
	 * 분류상세코드를 수정한다.
	 * @param cmmnDetailCode
	 * @throws Exception
	 */
	public void updateCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		update("CmmnDetailClCodeManageDAO.updateCmmnDetailClCode", cmmnDetailClCode);
	}

}
