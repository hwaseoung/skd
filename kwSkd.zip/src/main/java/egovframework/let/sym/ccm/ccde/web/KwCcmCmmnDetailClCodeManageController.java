package egovframework.let.sym.ccm.ccde.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.CmmnDetailClCode;
import egovframework.com.cmm.service.KwCmmUseService;
import egovframework.let.sym.ccm.ccc.service.CmmnClCode;
import egovframework.let.sym.ccm.ccc.service.CmmnClCodeVO;
import egovframework.let.sym.ccm.ccc.service.KwCcmCmmnClCodeManageService;
import egovframework.let.sym.ccm.ccde.service.CmmnDetailClCodeVO;
import egovframework.let.sym.ccm.ccde.service.KwCcmCmmnDetailClCodeManageService;

@Controller
public class KwCcmCmmnDetailClCodeManageController {

	@Resource(name = "CmmnDetailClCodeManageService")
    private KwCcmCmmnDetailClCodeManageService cmmnDetailClCodeManageService;

	@Resource(name = "CmmnClCodeManageService")
    private KwCcmCmmnClCodeManageService cmmnClCodeManageService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** cmmUseService */
   	@Resource(name = "KwCmmUseService")
   	private KwCmmUseService cmmUseService;

	@Autowired
	private DefaultBeanValidator beanValidator;

	/**
	 * 분류상세코드를 삭제한다.
	 * @param loginVO
	 * @param cmmnDetailCode
	 * @param model
	 * @return "forward:/sym/ccm/cde/KwCcmCmmnDetailClCodeList.do"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccde/KwCcmCmmnDetailClCodeRemove.do")
	public String deleteCmmnDetailClCode (@ModelAttribute("loginVO") LoginVO loginVO
			, CmmnDetailClCode cmmnDetailClCode
			, ModelMap model
			) throws Exception {
    	cmmnDetailClCodeManageService.deleteCmmnDetailClCode(cmmnDetailClCode);
        return "redirect:/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do";
	}

	/**
	 * 분류상세코드를 등록한다.
	 * @param loginVO
	 * @param cmmnDetailCode
	 * @param cmmnCode
	 * @param bindingResult
	 * @param model
	 * @return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeRegist"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccde/KwCcmCmmnDetailClCodeRegist.do")
	public String insertCmmnDetailClCode	(@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("cmmnDetailClCode") CmmnDetailClCode cmmnDetailClCode
			, @ModelAttribute("cmmnClCode") CmmnClCode cmmnClCode
			, BindingResult bindingResult
			, @RequestParam Map <String, Object> commandMap
			, ModelMap model
			)	throws Exception {

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");		
		loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	if   (cmmnDetailClCode.getClCode() == null
        		||cmmnDetailClCode.getClCode().equals("")
        		||cmmnDetailClCode.getClCodeId() == null
        		||cmmnDetailClCode.getClCodeId().equals("")
        		||sCmd.equals("")) {

	    		//공통코드 활용
	        	ComDefaultCodeVO vo = new ComDefaultCodeVO();
	        	//작업그룹
	        	vo.setTableNm("ALL");
	    		List<?> CmmnClCodeList = cmmUseService.selectCmmClCode(vo);
	        	model.addAttribute("cmmnClCodeList", CmmnClCodeList);

                return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeRegist";
    	} else if (sCmd.equals("Regist")) {

	        beanValidator.validate(cmmnDetailClCode, bindingResult);
			if (bindingResult.hasErrors()){
				//공통코드 활용
	        	ComDefaultCodeVO vo = new ComDefaultCodeVO();
	        	//작업그룹
	        	vo.setTableNm("ALL");
	    		List<?> CmmnClCodeList = cmmUseService.selectCmmClCode(vo);
	        	model.addAttribute("cmmnClCodeList", CmmnClCodeList);

	            return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeRegist";
			}

	    	cmmnDetailClCode.setFrstRegisterId(loginVO.getId());
	    	cmmnDetailClCodeManageService.insertCmmnDetailClCode(cmmnDetailClCode);
	        return "redirect:/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do";
    	}  else {
    		return "redirect:/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do";
    	}
    }
    
    /**
	 * 분류상세코드 상세항목을 조회한다.
	 * @param loginVO
	 * @param cmmnDetailCode
	 * @param model
	 * @return "cmm/sym/ccm/KwCcmCmmnDetailClCodeDetail"
	 * @throws Exception
	 */
	@RequestMapping(value="/sym/ccm/ccde/KwCcmCmmnDetailClCodeDetail.do")
 	public String selectCmmnDetailClCodeDetail (@ModelAttribute("loginVO") LoginVO loginVO
 			, CmmnDetailClCode cmmnDetailClCode
 			,	ModelMap model
 			)	throws Exception {
    	CmmnDetailClCode vo = cmmnDetailClCodeManageService.selectCmmnDetailClCodeDetail(cmmnDetailClCode);
		model.addAttribute("result", vo);

		return "cmm/sym/ccm/KwCcmCmmnDetailClCodeDetail";
	}
	
	/**
	 * 분류상세코드 목록을 조회한다.
     * @param loginVO
     * @param searchVO
     * @param model
     * @return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeList"
     * @throws Exception
     */
    @RequestMapping(value="/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do")
	public String selectCmmnDetailClCodeList (@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("searchVO") CmmnDetailClCodeVO searchVO
			, ModelMap model
			) throws Exception {
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        model.addAttribute("resultList", cmmnDetailClCodeManageService.selectCmmnDetailClCodeList(searchVO));

        int totCnt = cmmnDetailClCodeManageService.selectCmmnDetailClCodeListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

        return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeList";
	}
    
    /**
	 * 분류상세코드를 수정한다.
	 * @param loginVO
	 * @param cmmnDetailClCode
	 * @param bindingResult
	 * @param commandMap
	 * @param model
	 * @return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeModify"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccde/KwCcmCmmnDetailClCodeModify.do")
	public String updateCmmnDetailClCode (@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("cmmnDetailClCode") CmmnDetailClCode cmmnDetailClCode
			, BindingResult bindingResult
			, @RequestParam Map <String, Object> commandMap
			, ModelMap model
			) throws Exception {
    	
		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");
		loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
    	if (sCmd.equals("")) {
    		CmmnDetailClCode vo = cmmnDetailClCodeManageService.selectCmmnDetailClCodeDetail(cmmnDetailClCode);
    		model.addAttribute("cmmnDetailClCode", vo);

    		return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeModify";
    	} else if (sCmd.equals("Modify")) {
            beanValidator.validate(cmmnDetailClCode, bindingResult);
    		if (bindingResult.hasErrors()){
        		CmmnDetailClCode vo = cmmnDetailClCodeManageService.selectCmmnDetailClCodeDetail(cmmnDetailClCode);
        		model.addAttribute("cmmnDetailClCode", vo);

        		return "/cmm/sym/ccm/KwCcmCmmnDetailClCodeModify";
    		}

    		cmmnDetailClCode.setLastUpdusrId(loginVO.getId());
    		cmmnDetailClCodeManageService.updateCmmnDetailClCode(cmmnDetailClCode);
	        return "redirect:/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do";
    	} else {
    		return "redirect:/sym/ccm/ccde/KwCcmCmmnDetailClCodeList.do";
    	}
    }

}