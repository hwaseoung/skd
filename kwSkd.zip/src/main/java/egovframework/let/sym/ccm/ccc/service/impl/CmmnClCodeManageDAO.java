package egovframework.let.sym.ccm.ccc.service.impl;

import java.util.List;

import egovframework.let.sym.ccm.ccc.service.CmmnClCode;
import egovframework.let.sym.ccm.ccc.service.CmmnClCodeVO;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;

import org.springframework.stereotype.Repository;

@Repository("CmmnClCodeManageDAO")
public class CmmnClCodeManageDAO extends EgovAbstractMapper {

	/**
	 * 분류코드를 삭제한다.
	 * @param cmmnClCode
	 * @throws Exception
	 */
	public void deleteCmmnClCode(CmmnClCode cmmnClCode) throws Exception {
		delete("CmmnClCodeManageDAO.deleteCmmnClCode", cmmnClCode);
	}


	/**
	 * 분류코드를 등록한다.
	 * @param cmmnClCode
	 * @throws Exception
	 */
	public void insertCmmnClCode(CmmnClCode cmmnClCode) throws Exception {
        insert("CmmnClCodeManageDAO.insertCmmnClCode", cmmnClCode);
	}

	/**
	 * 분류코드 상세항목을 조회한다.
	 * @param cmmnClCode
	 * @return CmmnClCode(분류코드)
	 */
	public CmmnClCode selectCmmnClCodeDetail(CmmnClCode cmmnClCode) throws Exception {
		return (CmmnClCode)selectOne("CmmnClCodeManageDAO.selectCmmnClCodeDetail", cmmnClCode);
	}


    /**
	 * 분류코드 목록을 조회한다.
     * @param searchVO
     * @return List(분류코드 목록)
     * @throws Exception
     */
	public List<?> selectCmmnClCodeList(CmmnClCodeVO searchVO) throws Exception {
        return list("CmmnClCodeManageDAO.selectCmmnClCodeList", searchVO);
    }

    /**
	 * 분류코드 총 갯수를 조회한다.
     * @param searchVO
     * @return int(분류코드 총 갯수)
     */
    public int selectCmmnClCodeListTotCnt(CmmnClCodeVO searchVO) throws Exception {
        return (Integer)selectOne("CmmnClCodeManageDAO.selectCmmnClCodeListTotCnt", searchVO);
    }

	/**
	 * 분류코드를 수정한다.
	 * @param cmmnClCode
	 * @throws Exception
	 */
	public void updateCmmnClCode(CmmnClCode cmmnClCode) throws Exception {
		update("CmmnClCodeManageDAO.updateCmmnClCode", cmmnClCode);
	}

}
