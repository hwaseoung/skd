package egovframework.let.sym.ccm.ccde.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.service.CmmnDetailClCode;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.let.sym.ccm.ccde.service.CmmnDetailClCodeVO;
import egovframework.let.sym.ccm.ccde.service.KwCcmCmmnDetailClCodeManageService;



@Service("CmmnDetailClCodeManageService")
public class KwCcmCmmnDetailClCodeManageServiceImpl extends EgovAbstractServiceImpl implements KwCcmCmmnDetailClCodeManageService {

    @Resource(name="CmmnDetailClCodeManageDAO")
    private CmmnDetailClCodeManageDAO cmmnDetailClCodeManageDAO;

    /**
	 * 분류상세코드를 삭제한다.
	 */
	@Override
	public void deleteCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		cmmnDetailClCodeManageDAO.deleteCmmnDetailClCode(cmmnDetailClCode);
		
	}

	/**
	 * 분류상세코드를 등록한다.
	 */
	@Override
	public void insertCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		cmmnDetailClCodeManageDAO.insertCmmnDetailClCode(cmmnDetailClCode);
		
	}

	/**
	 * 분류상세코드 상세항목을 조회한다.
	 */
	@Override
	public CmmnDetailClCode selectCmmnDetailClCodeDetail(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		
		return cmmnDetailClCodeManageDAO.selectCmmnDetailClCodeDetail(cmmnDetailClCode);
	}

	/**
	 * 분류상세코드 목록을 조회한다.
	 */
	@Override
	public List<?> selectCmmnDetailClCodeList(CmmnDetailClCodeVO searchVO) throws Exception {
		return cmmnDetailClCodeManageDAO.selectCmmnDetailClCodeList(searchVO);
	}

	/**
	 * 분류상세코드 총 갯수를 조회한다.
	 */
	@Override
	public int selectCmmnDetailClCodeListTotCnt(CmmnDetailClCodeVO searchVO) throws Exception {
		return cmmnDetailClCodeManageDAO.selectCmmnDetailClCodeListTotCnt(searchVO);
	}

	/**
	 * 분류상세코드를 수정한다.
	 */
	@Override
	public void updateCmmnDetailClCode(CmmnDetailClCode cmmnDetailClCode) throws Exception {
		cmmnDetailClCodeManageDAO.updateCmmnDetailClCode(cmmnDetailClCode);
		
	}


}
