package egovframework.let.sym.ccm.ccc.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.KwCmmUseService;
import egovframework.let.sym.ccm.ccc.service.CmmnClCode;
import egovframework.let.sym.ccm.ccc.service.CmmnClCodeVO;
import egovframework.let.sym.ccm.ccc.service.KwCcmCmmnClCodeManageService;

@Controller
public class KwCcmCmmnClCodeManageController {
	@Resource(name = "CmmnClCodeManageService")
    private KwCcmCmmnClCodeManageService cmmnClCodeManageService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** cmmUseService */
	@Resource(name = "KwCmmUseService")
	private KwCmmUseService cmmUseService;

	@Autowired
	private DefaultBeanValidator beanValidator;

	/**
	 * 분류코드를 삭제한다.
	 * @param loginVO
	 * @param cmmnClCode
	 * @param model
	 * @return "forward:/sym/ccm/ccc/KwCcmCmmnClCodeList.do"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeRemove.do")
	public String deleteCmmnClCode (@ModelAttribute("loginVO") LoginVO loginVO
			, CmmnClCode cmmnClCode
			, ModelMap model
			) throws Exception {
    	 cmmnClCodeManageService.deleteCmmnClCode(cmmnClCode);
        return "redirect:/sym/ccm/ccc/KwCcmCmmnClCodeList.do";
	}

	/**
	 * 분류코드를 등록한다.
	 * @param loginVO
	 * @param cmmnClCode
	 * @param bindingResult
	 * @return "/cmm/sym/ccm/KwCcmCmmnClCodeRegist"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeRegist.do")
	public String insertCmmnClCode (@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("cmmnClCode") CmmnClCode cmmnClCode
			, BindingResult bindingResult
			) throws Exception {
    	
    	loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
    	
    	if   (cmmnClCode.getClCode() == null
    		||cmmnClCode.getClCode().equals("")) {
    		return "/cmm/sym/ccm/KwCcmCmmnClCodeRegist";
    	}

        beanValidator.validate(cmmnClCode, bindingResult);
		if (bindingResult.hasErrors()){
    		return "/cmm/sym/ccm/KwCcmCmmnClCodeRegist";
		}

    	cmmnClCode.setFrstRegisterId(loginVO.getId());
    	cmmnClCodeManageService.insertCmmnClCode(cmmnClCode);
        return "redirect:/sym/ccm/ccc/KwCcmCmmnClCodeList.do";
    }

	/**
	 * 분류코드 상세항목을 조회한다.
	 * @param loginVO
	 * @param cmmnClCode
	 * @param model
	 * @return "cmm/sym/ccm/KwCcmCmmnClCodeDetail"
	 * @throws Exception
	 */
	@RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeDetail.do")
 	public String selectCmmnClCodeDetail (@ModelAttribute("loginVO") LoginVO loginVO
 			, CmmnClCode cmmnClCode
 			, ModelMap model
 			) throws Exception {
		CmmnClCode vo = cmmnClCodeManageService.selectCmmnClCodeDetail(cmmnClCode);
		model.addAttribute("result", vo);

		return "cmm/sym/ccm/KwCcmCmmnClCodeDetail";
	}

    /**
	 * 분류코드 목록을 조회한다.
     * @param loginVO
     * @param searchVO
     * @param model
     * @return "/cmm/sym/ccm/KwCcmCmmnClCodeList"
     * @throws Exception
     */
    @RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeList.do")
	public String selectCmmnClCodeList (@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("searchVO") CmmnClCodeVO searchVO
			, ModelMap model
			) throws Exception {

    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        model.addAttribute("resultList", cmmnClCodeManageService.selectCmmnClCodeList(searchVO));

        int totCnt = cmmnClCodeManageService.selectCmmnClCodeListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

        return "/cmm/sym/ccm/KwCcmCmmnClCodeList";
	}

	/**
	 * 분류코드를 수정한다.
	 * @param loginVO
	 * @param cmmnClCode
	 * @param bindingResult
	 * @param commandMap
	 * @param model
	 * @return "/cmm/sym/ccm/KwCcmCmmnClCodeModify"
	 * @throws Exception
	 */
    @RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeModify.do")
	public String updateCmmnClCode (@ModelAttribute("loginVO") LoginVO loginVO
			, @ModelAttribute("administCode") CmmnClCode cmmnClCode
			, BindingResult bindingResult
			, @RequestParam Map <String, Object> commandMap
			, ModelMap model
			) throws Exception {
		
    	String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");
		loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
    	if (sCmd.equals("")) {
    		CmmnClCode vo = cmmnClCodeManageService.selectCmmnClCodeDetail(cmmnClCode);
    		model.addAttribute("cmmnClCode", vo);

    		return "/cmm/sym/ccm/KwCcmCmmnClCodeModify";
    	} else if (sCmd.equals("Modify")) {
            beanValidator.validate(cmmnClCode, bindingResult);
    		if (bindingResult.hasErrors()){
        		CmmnClCode vo = cmmnClCodeManageService.selectCmmnClCodeDetail(cmmnClCode);
        		model.addAttribute("cmmnClCode", vo);

        		return "/cmm/sym/ccm/KwCcmCmmnClCodeModify";
    		}
    		cmmnClCode.setLastUpdusrId(loginVO.getId());
	    	cmmnClCodeManageService.updateCmmnClCode(cmmnClCode);
	        return "redirect:/sym/ccm/ccc/KwCcmCmmnClCodeList.do";
    	} else {
    		return "redirect:/sym/ccm/ccc/KwCcmCmmnClCodeList.do";
    	}
    }
    
    @SuppressWarnings("unchecked")
	@RequestMapping(value="/sym/ccm/ccc/KwCcmCmmnClCodeSelect.do")
	@ResponseBody
	public ModelAndView scheduleInsert(@ModelAttribute("comDefaultCodeVO") ComDefaultCodeVO vo,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {
		
		ModelAndView mav = new ModelAndView("jsonView");
		JSONObject jsonObj = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		HashMap<String, Object> hash = new HashMap<String, Object>();
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		vo.setCode(loginVO.getClCodeId());		
		//작업세부그룹
		List <?> cmmnClCodList= cmmUseService.selectCmmClCodeDetail(vo);
		CmmnDetailCode emp = new CmmnDetailCode();
		
    	for(int i=0; i < cmmnClCodList.size(); i++) {
    		emp = (CmmnDetailCode)cmmnClCodList.get(i);
    		
    		hash.put("codeId", emp.getCode());
    		hash.put("codeNm", emp.getCodeNm());
			
			jsonObj = new JSONObject(hash); 
			jsonArr.add(jsonObj); 
		}
		
    	mav.addObject("result", jsonArr);
		
		return mav;
	}

}