//한국시간으로 변경
function fn_toISO(date) {
	var offset = date.getTimezoneOffset() * 60000;
	var today = new Date(date - offset);
	return today.toISOString();
}

//시간 더하기빼기
function AddMin(min) {
	var today = new Date();
	today.setMinutes(today.getMinutes() + min);
    return today;
}

//일자 더하기 빼기 후 유효성 체크
function AddDays(date,days) {
	var today = new Date();
	var result;
    if(fn_toISO(AddMin(0)).substr(0,10).replace('T',' ') < date.substr(0,10)){
    	msg ="시작일자";
    	result = new Date($("#schdulBgnDt").val());
    	result.setDate(new Date($("#schdulBgnDt").val()).getDate() + days);
    	altDate = fn_toISO(new Date($("#schdulBgnDt").val())).substr(0,10)
    }else{
    	msg ="현재일자";
    	result = new Date();
    	result.setDate(result.getDate() + days);
    	altDate = fn_toISO(AddMin(0)).substr(0,10);
    }
    
    if(today < result){
    	return true;
    }else{
    	$("#sendSe").val('');
    	alert(msg+'('+altDate+')를 확인 후 선택하세요.');
    	$('#schdulBgnDt').focus();
    	return false;
    }
}

//현재일자+1시간과 시작일자 비교
function toDayDiff(date) {
	var today = new Date();
	today = new Date(today.setMinutes(today.getMinutes() + 60));
	var startDt = new Date(date);
  	if(today < startDt){
    	return  "Y";
    }else{
    	
    	return "N";
    }
}

//재알림 체크 여부
function fnCheckYn(str) {
    if($('#checkYn').is(':checked')) {
    	 alert("재 알림을 해지하셨습니다.");
    	 $("#sendSe").attr("disabled",true);
    } else {
		if(str !="freg"){
			alert("재 알림을 선택하셨습니다.");
		}else{
			$('#checkYn').prop("checked", true);
			$('.f_chk_only').addClass('on');
		}
        $("#sendSe").removeAttr("disabled");
        $("#sendDt").removeAttr("disabled");
        $("#sendSe").val('');
        $("#sendDt").val('');
  	    $("#sendDt").hide();
    }
}

// 작업구분 코드 상세조회
function fn_code_seach(form){
	form.codeId.value =$('#clCode').val();
	$('#clCodeId').children('option:not(:first)').remove();
	if(form.codeId.value !=""){
		$.ajax({
	        url: '/sym/ccm/ccc/KwCcmCmmnClCodeSelect.do',
	        data: $("#codeForm").serialize(),
	        type: 'POST',
	        dataType: 'json',
	        success: function(data) {
	        	$.each(data.result, function(i, item) {
	        		//console.log(item.codeId);
	       			$('#clCodeId').append($('<option>', { 
	           	        value: item.codeId,
	           	        text : item.codeNm 
	           	    })); 
	        	});
	        }
    	});
	}
}

//시간 확인
function getDisplayEventDate(event) {

  var displayEventDate;

  //if (event.allDay == false) {
    var startTimeEventInfo = event.extendedProps.startB;
    var endTimeEventInfo = event.extendedProps.endB;
    displayEventDate = startTimeEventInfo + " ~ " + endTimeEventInfo;
  //} else {
    //displayEventDate = "하루종일";
  //}

  return displayEventDate;
}

//작업구분
function getDisplayEventClCode(event) {

  var displayEventClCode;

  if (event.clCodeNm != "" && event.clCodeNm !=null ) {
	  displayEventClCode = event.clCodeNm;
	  if(event.clCodeIdNm != "" && event.clCodeIdNm !=null ){
		   displayEventClCode = event.clCodeNm +' > '+ event.clCodeIdNm;
	  }
  }else{
	  displayEventClCode= "";
  }

  return displayEventClCode;
}

//주기 및 간격
function getDisplayRrule(event) {

  var displayRrule;
  var freq = event.extendedProps.schdulFreq;
  var interval = event.extendedProps.schdulInterval;

  if (freq == 'yearly') {
	  displayRrule = "'년' 주기 (간격 : " +interval+")";
  } else if(freq == 'monthly') {
     displayRrule = "'월' 주기 (간격 : " +interval+")";
  } else if(freq == 'weekly') {
     displayRrule = "'주' 주기 (간격 : " +interval+")";
  } else if(freq == 'daily') {
     displayRrule = "'일' 주기 (간격 : " +interval+")";
  } else{
	  displayRrule="없음";
  }


  return displayRrule;
}

//이름 마스킹
function maskingName(name) {
  if (name.length <= 2) {
    return name.replace(name.substring(0, 1), "*");
  }

  return (
    name[0] +
    "*".repeat(name.substring(1, name.length - 1).length) +
    name[name.length - 1]
  );
}

//캘린더 이동페이지 고정
function fn_Memory(){
	//달력 현재페이지 유지를 위해 한번더 조회
	$('#initView').val(calendar.currentData.currentViewType);
    $('#initDate').val(fn_toISO(calendar.currentData.currentDate).substring(0,10));
    //캘린더 초기화
    calendar.destroy();
	document.formSchdul.action = "/skd/scheduleView.do"; 
	document.formSchdul.method = "GET";  
	document.formSchdul.submit();
}

//알림일시 모달
function fn_sms_modal(str) {
	var url ="selectSmsList.do?schduleId="+str;
    var $dialog = $('<div id="modalSms"></div>')
	.html('<iframe style="border: 0px; " src="' +url+'" width="100%" height="100%"></iframe>')
	.dialog({
    	autoOpen: false,
        modal: true,
        width: 600,
        height: 490
	});
    $(".ui-dialog-titlebar").hide();
	$dialog.dialog('open');
}

//일정주기 모달
function fn_freq_modal(str) {
	var url ="selectFreqList.do?schduleId="+str;
    var $dialog = $('<div id="modalFreq"></div>')
	.html('<iframe style="border: 0px; " src="' +url+'" width="100%" height="100%"></iframe>')
	.dialog({
    	autoOpen: false,
        modal: true,
        width: 600,
        height: 490
	});
    $(".ui-dialog-titlebar").hide();
	$dialog.dialog('open');
}

//알람목록 모달 닫기
function fn_sms_modal_remove() {
	$('#modalSms').remove();
}

//일정 주기 모달 닫기
function fn_freq_modal_remove() {
	$('#modalFreq').remove();
}

function fnSelectPop(){
	var arg = canForm;
	if(arg.event.allDay){
		startDt= arg.event.startStr;
	 }else{
		startDt= arg.event.startStr.substr(0, 16).replace('T', ' ')
	 }
	var updateYn = toDayDiff(startDt);
	var url = "selectPop.do?updateYn="+updateYn;
    var $dialog = $('<div id="modalPop"></div>')
	.html('<iframe style="border: 0px; " src="'+url+'" width="100%" height="100%"></iframe>')
	.dialog({
    	autoOpen: false,
        modal: true,
        width: 500,
        height: 300
	});
    $(".ui-dialog-titlebar").hide();
	$dialog.dialog('open');
}

//수정 팝업
function fnUpdate(str) {
	$('#modalPop').remove();
	retVal = str;
	var arg = canForm;
	var schduleId= arg.event.id;
	var url = "scheduleUpdtPop.do?schduleId="+schduleId;
	if(retVal =='N'){
     	 var $dialog = $('<div id="modalPan"></div>')
     	.html('<iframe style="border: 0px; " src="' +url+'" width="100%" height="100%"></iframe>')
     	.dialog({
         	autoOpen: false,
             modal: true,
             width: 650,
             height: 840
     	});
         $(".ui-dialog-titlebar").hide();
     	$dialog.dialog('open');
	}else{
		if(arg.event.allDay){
			startDt= arg.event.startStr;
	    	endDt= arg.event.endStr; 
		 }else{
			startDt= arg.event.startStr.substr(0, 16).replace('T', ' ')
	    	endDt= arg.event.endStr.substr(0, 16).replace('T', ' ')
		 }
		var schdulFreqSn= arg.event.extendedProps.schdulFreqSn;
		url = "scheduleDropSize.do?schduleId="+schduleId+"&startDt="+startDt+"&endDt="+endDt+"&allDay="+arg.event.allDay+"&schdulFreqSn="+schdulFreqSn;
		var $dialog = $('<div id="modalPan"></div>')
	   	.html('<iframe style="border: 0px; " src="' +url+ '" width="100%" height="100%"></iframe>')
	   	.dialog({
	       	autoOpen: false,
	           modal: true,
	           width: 650,
	           height: 840
	   	});
	       $(".ui-dialog-titlebar").hide();
	   	$dialog.dialog('open');
	}
	
}

//새로고침
function fn_Refresh(){
	location.reload();
}

//모달창 닫기
function fn_egov_modal_remove() {
	$('#modalPan').remove();
	$('#modalPop').remove();
}

$(function() {
	var freq = true;
	//달력 설정
	jQuery.datetimepicker.setLocale('kr');
	$(".datetimepicker").datetimepicker({ 
		step:30,
		format: "Y-m-d H:i",
		allowTimes:[
			'08:00','08:30','09:00','09:30','10:00','10:30','11:00',
			'11:30','12:00','12:30','13:00','13:30','14:00','14:30',
			'15:00','15:30','16:00','16:30','17:00','17:30','18:00',
			'18:30','19:00','19:30','20:00'
		 ]
	});
	
	//종일여부
	$("#allDay").change(function() {
	    //종일여부 선택시 시간 제거
		if($("#allDay").val() == "true") {
			$('#schdulBgnDt').val($('#schdulBgnDt').val().substr(0, 10));
			$('#schdulEndDt').val($('#schdulEndDt').val().substr(0, 10));
		}  else {
			$('#schdulBgnDt').val('');
			$('#schdulEndDt').val('');
			alert('시간을 다시 선택해주세요.');
		}
	}) 
		
	//색상선택시
	$('#schdulClr').change(function () {
	    $(this).css('color', $(this).val());
	});
	
	//주기 선택시
	$('#schdulFreq').change(function () {
	    if(freq && $('#schdulId').val() == undefined){
			alert('과도한 일정주기 설정은 자제해 주시기 바랍니다.');
			if($('#schdulInterval').val()==""){
				$('#schdulInterval').val('1');
			}
			
			freq = false;
		}else if(freq && $('#schdulId').val() != undefined){
			alert('일정주기 변경시 알림일시 재설정이 필요합니다.');
			if($('#schdulInterval').val()==""){
				$('#schdulInterval').val('1');
			}
			freq = false;
			fnCheckYn("freg");
		}
	});
	
	//간격 변경시
	$('#schdulInterval').change(function () {
	  if(freq && $('#schdulId').val() != undefined){
		   alert('일정간격 변경시 알림일시 재설정이 필요합니다.');
		   freq = false;
		   fnCheckYn("freg");
	   }
	});
	
	//담당자 변경시
	$('#chargerGp').change(function () {
	    if(freq && $('#schdulId').val() != undefined){
		   alert('일정간격 변경시 알림일시 재설정이 필요합니다.');
		   freq = false;
		   fnCheckYn("freg");
	    }
		
		if($(this).val()=="group"){
			$('#schdulChargerTelNo').hide();
			$('#schdulChargerNm').hide();
			$('#schdulChargerNm').val($(this).val());
			$('#schdulChargerTelNo').val('');
			$('#charger').show();
			$('#charger').append('<span class="f_txt_inner ml5" style="color: #ff0000ab;"> 작업구분에 속한 사용자들에게 발송</span>');
		}else{
			$('#charger').empty();
			$('#schdulChargerTelNo').show();
			$('#schdulChargerNm').show();
			$('#schdulChargerNm').val('');
			$('#schdulChargerTelNo').val('');
		}
	});
	
})